﻿namespace Mercado.Model
{
    public class Venda
    {
        public int IdVenda { get; set; }
        public DateTime DataVenda { get; set; }
        public int IdCliente { get; set; }
        public int IdUsuario { get; set; }
        public decimal ValorTotal { get; set; }

      
        public List<ItemVenda> ItensVenda { get; set; } = new List<ItemVenda>();
    }
}
