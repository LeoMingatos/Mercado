﻿using Mercado.Controller;
using Mercado.Model;
using System;
using System.Data;
using System.Windows.Forms;

namespace Mercado
{
    public partial class CadUsuario : Form
    {
        UsuarioController usuarioController = new UsuarioController();

       

        private void CarregarUsuarios()
        {
            dgvUsuarios.DataSource = usuarioController.GetAll();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Usuario u = new Usuario
            {
                Nome = txtNome.Text,
                Login = txtLogin.Text,
                Senha = txtSenha.Text,
                NivelAcesso = cboNivelAcesso.Text
            };

            usuarioController.Inserir(u);
            MessageBox.Show("Usuário cadastrado com sucesso!");
            CarregarUsuarios();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (txtIdUsuario.Text == "")
            {
                MessageBox.Show("Selecione um usuário para alterar.");
                return;
            }

            Usuario u = new Usuario
            {
                IdUsuario = int.Parse(txtIdUsuario.Text),
                Nome = txtNome.Text,
                Login = txtLogin.Text,
                Senha = txtSenha.Text,
                NivelAcesso = cboNivelAcesso.Text
            };

            usuarioController.Alterar(u);
            MessageBox.Show("Usuário alterado com sucesso!");
            CarregarUsuarios();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (txtIdUsuario.Text == "")
            {
                MessageBox.Show("Selecione um usuário para excluir.");
                return;
            }

            int id = int.Parse(txtIdUsuario.Text);
            usuarioController.Excluir(id);
            MessageBox.Show("Usuário excluído com sucesso!");
            CarregarUsuarios();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            dgvUsuarios.DataSource = usuarioController.GetByNome(txtPesquisar.Text);
        }

        private void dgvUsuarios_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvUsuarios.Rows[e.RowIndex];
                txtIdUsuario.Text = row.Cells["IdUsuario"].Value.ToString();
                txtNome.Text = row.Cells["Nome"].Value.ToString();
                txtLogin.Text = row.Cells["Login"].Value.ToString();
                txtSenha.Text = row.Cells["Senha"].Value.ToString();
                cboNivelAcesso.Text = row.Cells["NivelAcesso"].Value.ToString();
            }
        }
    }
}