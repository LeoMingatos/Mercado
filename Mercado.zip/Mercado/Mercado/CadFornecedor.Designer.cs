﻿using Mercado.Controller;
using Mercado.Model;

namespace Mercado
{
    public partial class  CadFornecedor : Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtId = new TextBox();
            txtRazaoSocial = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtCNPJ = new TextBox();
            txtTelefone = new TextBox();
            txtEmail = new TextBox();
            bntNovo = new Button();
            btnSalvar = new Button();
            btnExcluir = new Button();
            btnPesquisar = new Button();
            dgvFornecedores = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvFornecedores).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(21, 15);
            label1.TabIndex = 0;
            label1.Text = "ID:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 40);
            label2.Name = "label2";
            label2.Size = new Size(75, 15);
            label2.TabIndex = 1;
            label2.Text = "Razão Social:";
            // 
            // txtId
            // 
            txtId.Location = new Point(93, 6);
            txtId.Name = "txtId";
            txtId.ReadOnly = true;
            txtId.Size = new Size(100, 23);
            txtId.TabIndex = 2;
            // 
            // txtRazaoSocial
            // 
            txtRazaoSocial.Location = new Point(93, 37);
            txtRazaoSocial.Name = "txtRazaoSocial";
            txtRazaoSocial.Size = new Size(100, 23);
            txtRazaoSocial.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(242, 9);
            label3.Name = "label3";
            label3.Size = new Size(37, 15);
            label3.TabIndex = 4;
            label3.Text = "CNPJ:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(242, 45);
            label4.Name = "label4";
            label4.Size = new Size(54, 15);
            label4.TabIndex = 5;
            label4.Text = "Telefone:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(424, 14);
            label5.Name = "label5";
            label5.Size = new Size(39, 15);
            label5.TabIndex = 6;
            label5.Text = "Email:";
            // 
            // txtCNPJ
            // 
            txtCNPJ.Location = new Point(302, 9);
            txtCNPJ.Name = "txtCNPJ";
            txtCNPJ.ReadOnly = true;
            txtCNPJ.Size = new Size(100, 23);
            txtCNPJ.TabIndex = 7;
            // 
            // txtTelefone
            // 
            txtTelefone.Location = new Point(302, 42);
            txtTelefone.Name = "txtTelefone";
            txtTelefone.ReadOnly = true;
            txtTelefone.Size = new Size(100, 23);
            txtTelefone.TabIndex = 8;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(469, 11);
            txtEmail.Name = "txtEmail";
            txtEmail.ReadOnly = true;
            txtEmail.Size = new Size(100, 23);
            txtEmail.TabIndex = 9;
            // 
            // bntNovo
            // 
            bntNovo.Location = new Point(35, 245);
            bntNovo.Name = "bntNovo";
            bntNovo.Size = new Size(75, 23);
            bntNovo.TabIndex = 10;
            bntNovo.Text = "NOVO";
            bntNovo.UseVisualStyleBackColor = true;
            // 
            // btnSalvar
            // 
            btnSalvar.Location = new Point(175, 245);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(75, 23);
            btnSalvar.TabIndex = 11;
            btnSalvar.Text = "SALVAR";
            btnSalvar.UseVisualStyleBackColor = true;
            // 
            // btnExcluir
            // 
            btnExcluir.Location = new Point(411, 245);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(75, 23);
            btnExcluir.TabIndex = 12;
            btnExcluir.Text = "EXCLUIR";
            btnExcluir.UseVisualStyleBackColor = true;
            // 
            // btnPesquisar
            // 
            btnPesquisar.Location = new Point(637, 245);
            btnPesquisar.Name = "btnPesquisar";
            btnPesquisar.Size = new Size(75, 23);
            btnPesquisar.TabIndex = 13;
            btnPesquisar.Text = "PESQUISAR";
            btnPesquisar.UseVisualStyleBackColor = true;
            // 
            // dgvFornecedores
            // 
            dgvFornecedores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvFornecedores.Location = new Point(12, 76);
            dgvFornecedores.Name = "dgvFornecedores";
            dgvFornecedores.Size = new Size(739, 150);
            dgvFornecedores.TabIndex = 14;
            // 
            // CadFornecedor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(778, 303);
            Controls.Add(dgvFornecedores);
            Controls.Add(btnPesquisar);
            Controls.Add(btnExcluir);
            Controls.Add(btnSalvar);
            Controls.Add(bntNovo);
            Controls.Add(txtEmail);
            Controls.Add(txtTelefone);
            Controls.Add(txtCNPJ);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(txtRazaoSocial);
            Controls.Add(txtId);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "CadFornecedor";
            Text = "Cadastro de Fornecedor";
            ((System.ComponentModel.ISupportInitialize)dgvFornecedores).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.TextBox txtRazaoSocial;
        private System.Windows.Forms.Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtCNPJ;
        private TextBox txtTelefone;
        private TextBox txtEmail;
        private Button bntNovo;
        private Button btnSalvar;
        private Button btnExcluir;
        private Button btnPesquisar;
        private DataGridView dgvFornecedores;
        FornecedorController controller = new FornecedorController();

        public CadFornecedor()
        {
            InitializeComponent();
            AtualizarGrid();
        }

        private void AtualizarGrid()
        {
            dgvFornecedores.DataSource = null;
            dgvFornecedores.DataSource = controller.GetAll();
        }

        private void LimparCampos()
        {
            txtId.Clear();
            txtRazaoSocial.Clear();
            txtCNPJ.Clear();
            txtTelefone.Clear();
            txtEmail.Clear();
            txtRazaoSocial.Focus();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtRazaoSocial.Text == "")
            {
                MessageBox.Show("Preencha a Razão Social!");
                return;
            }

            Fornecedor fornecedor = new Fornecedor
            {
                RazaoSocial = txtRazaoSocial.Text,
                CNPJ = txtCNPJ.Text,
                Telefone = txtTelefone.Text,
                Email = txtEmail.Text
            };

            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                controller.Inserir(fornecedor);
                MessageBox.Show("Fornecedor cadastrado com sucesso!");
            }
            else
            {
                fornecedor.IdFornecedor = Convert.ToInt32(txtId.Text);
                controller.Alterar(fornecedor);
                MessageBox.Show("Fornecedor atualizado com sucesso!");
            }

            AtualizarGrid();
            LimparCampos();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                MessageBox.Show("Selecione um fornecedor para excluir!");
                return;
            }

            int id = Convert.ToInt32(txtId.Text);
            controller.Excluir(id);
            MessageBox.Show("Fornecedor excluído com sucesso!");

            AtualizarGrid();
            LimparCampos();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            string nome = txtRazaoSocial.Text;
            dgvFornecedores.DataSource = controller.GetByRazaoSocial(nome);
        }

        private void dgvFornecedores_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvFornecedores.Rows[e.RowIndex];
                txtId.Text = row.Cells["IdFornecedor"].Value.ToString();
                txtRazaoSocial.Text = row.Cells["RazaoSocial"].Value.ToString();
                txtCNPJ.Text = row.Cells["CNPJ"].Value.ToString();
                txtTelefone.Text = row.Cells["Telefone"].Value.ToString();
                txtEmail.Text = row.Cells["Email"].Value.ToString();
            }
        }

    }
}
