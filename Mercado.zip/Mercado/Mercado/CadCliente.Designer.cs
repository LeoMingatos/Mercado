﻿using Mercado.Controller;
using Mercado.Model;

namespace Mercado
{
    public partial class CadCliente : Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbdId = new Label();
            txtId = new TextBox();
            label1 = new Label();
            txtNome = new TextBox();
            label2 = new Label();
            txtCpf = new TextBox();
            label3 = new Label();
            label4 = new Label();
            txtTelefone = new TextBox();
            txtEmail = new TextBox();
            btnNovo = new Button();
            btnExcluir = new Button();
            btnSalvar = new Button();
            btnPesquisar = new Button();
            dgvClientes = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvClientes).BeginInit();
            SuspendLayout();
            // 
            // lbdId
            // 
            lbdId.AutoSize = true;
            lbdId.Location = new Point(12, 9);
            lbdId.Name = "lbdId";
            lbdId.Size = new Size(21, 15);
            lbdId.TabIndex = 0;
            lbdId.Text = "ID:";
            // 
            // txtId
            // 
            txtId.Location = new Point(48, 6);
            txtId.Name = "txtId";
            txtId.ReadOnly = true;
            txtId.Size = new Size(100, 23);
            txtId.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 43);
            label1.Name = "label1";
            label1.Size = new Size(43, 15);
            label1.TabIndex = 2;
            label1.Text = "Nome:";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(58, 40);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(100, 23);
            txtNome.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 78);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 4;
            label2.Text = "CPF:";
            // 
            // txtCpf
            // 
            txtCpf.Location = new Point(58, 78);
            txtCpf.Name = "txtCpf";
            txtCpf.Size = new Size(100, 23);
            txtCpf.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(227, 14);
            label3.Name = "label3";
            label3.Size = new Size(54, 15);
            label3.TabIndex = 6;
            label3.Text = "Telefone:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(227, 48);
            label4.Name = "label4";
            label4.Size = new Size(39, 15);
            label4.TabIndex = 7;
            label4.Text = "Email:";
            // 
            // txtTelefone
            // 
            txtTelefone.Location = new Point(296, 14);
            txtTelefone.Name = "txtTelefone";
            txtTelefone.Size = new Size(100, 23);
            txtTelefone.TabIndex = 8;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(296, 48);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(100, 23);
            txtEmail.TabIndex = 9;
            // 
            // btnNovo
            // 
            btnNovo.Location = new Point(35, 313);
            btnNovo.Name = "btnNovo";
            btnNovo.Size = new Size(75, 23);
            btnNovo.TabIndex = 10;
            btnNovo.Text = "NOVO";
            btnNovo.UseVisualStyleBackColor = true;
            // 
            // btnExcluir
            // 
            btnExcluir.Location = new Point(682, 313);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(75, 23);
            btnExcluir.TabIndex = 11;
            btnExcluir.Text = "EXCLUIR";
            btnExcluir.UseVisualStyleBackColor = true;
            // 
            // btnSalvar
            // 
            btnSalvar.Location = new Point(135, 313);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(75, 23);
            btnSalvar.TabIndex = 12;
            btnSalvar.Text = "SALVAR";
            btnSalvar.UseVisualStyleBackColor = true;
            // 
            // btnPesquisar
            // 
            btnPesquisar.Location = new Point(589, 313);
            btnPesquisar.Name = "btnPesquisar";
            btnPesquisar.Size = new Size(75, 23);
            btnPesquisar.TabIndex = 13;
            btnPesquisar.Text = "PESQUISAR";
            btnPesquisar.UseVisualStyleBackColor = true;
            // 
            // dgvClientes
            // 
            dgvClientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvClientes.Location = new Point(12, 107);
            dgvClientes.Name = "dgvClientes";
            dgvClientes.ReadOnly = true;
            dgvClientes.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvClientes.Size = new Size(745, 200);
            dgvClientes.TabIndex = 14;
            // 
            // CadCliente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgvClientes);
            Controls.Add(btnPesquisar);
            Controls.Add(btnSalvar);
            Controls.Add(btnExcluir);
            Controls.Add(btnNovo);
            Controls.Add(txtEmail);
            Controls.Add(txtTelefone);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(txtCpf);
            Controls.Add(label2);
            Controls.Add(txtNome);
            Controls.Add(label1);
            Controls.Add(txtId);
            Controls.Add(lbdId);
            Name = "CadCliente";
            Text = "CadCliente";
            ((System.ComponentModel.ISupportInitialize)dgvClientes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbdId;
        private TextBox txtId;
        private Label label1;
        private TextBox txtNome;
        private Label label2;
        private TextBox txtCpf;
        private Label label3;
        private Label label4;
        private TextBox txtTelefone;
        private TextBox txtEmail;
        private Button btnNovo;
        private Button btnExcluir;
        private Button btnSalvar;
        private Button btnPesquisar;
        private DataGridView dgvClientes;

        ClienteController controller = new ClienteController();

        public CadCliente()
        {
            InitializeComponent();
            AtualizarGrid();
        }

        private void AtualizarGrid()
        {
            dgvClientes.DataSource = null;
            dgvClientes.DataSource = controller.GetAll();
        }

        private void LimparCampos()
        {
            txtId.Clear();
            txtNome.Clear();
            txtCpf.Clear();
            txtTelefone.Clear();
            txtEmail.Clear();
            txtNome.Focus();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Preencha o nome!");
                return;
            }

            Cliente cliente = new Cliente
            {
                Nome = txtNome.Text,
                CPF = txtCpf.Text,
                Telefone = txtTelefone.Text,
                Email = txtEmail.Text
            };

            // Se não há ID, é novo cadastro
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                controller.Inserir(cliente);
                MessageBox.Show("Cliente cadastrado com sucesso!");
            }
            else
            {
                cliente.IdCliente = Convert.ToInt32(txtId.Text);
                controller.Alterar(cliente);
                MessageBox.Show("Cliente atualizado com sucesso!");
            }

            AtualizarGrid();
            LimparCampos();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                MessageBox.Show("Selecione um cliente para excluir!");
                return;
            }

            int id = Convert.ToInt32(txtId.Text);
            controller.Excluir(id);

            MessageBox.Show("Cliente excluído com sucesso!");
            AtualizarGrid();
            LimparCampos();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            dgvClientes.DataSource = controller.GetByName(nome);
        }

        private void dgvClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvClientes.Rows[e.RowIndex];
                txtId.Text = row.Cells["IdCliente"].Value.ToString();
                txtNome.Text = row.Cells["Nome"].Value.ToString();
                txtCpf.Text = row.Cells["CPF"].Value.ToString();
                txtTelefone.Text = row.Cells["Telefone"].Value.ToString();
                txtEmail.Text = row.Cells["Email"].Value.ToString();
            }
        }
    }
}