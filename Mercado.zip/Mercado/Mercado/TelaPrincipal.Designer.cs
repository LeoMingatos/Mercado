﻿namespace Mercado
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            cadastrosToolStripMenuItem = new ToolStripMenuItem();
            clienteToolStripMenuItem = new ToolStripMenuItem();
            produtoToolStripMenuItem = new ToolStripMenuItem();
            fornecedirToolStripMenuItem = new ToolStripMenuItem();
            usuárioToolStripMenuItem = new ToolStripMenuItem();
            mOVIMENTAÇÕESToolStripMenuItem = new ToolStripMenuItem();
            vendaToolStripMenuItem = new ToolStripMenuItem();
            rELATÓRIOSToolStripMenuItem = new ToolStripMenuItem();
            históricoDeVendasToolStripMenuItem = new ToolStripMenuItem();
            sAIRToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { cadastrosToolStripMenuItem, mOVIMENTAÇÕESToolStripMenuItem, rELATÓRIOSToolStripMenuItem, sAIRToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // cadastrosToolStripMenuItem
            // 
            cadastrosToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { clienteToolStripMenuItem, produtoToolStripMenuItem, fornecedirToolStripMenuItem, usuárioToolStripMenuItem });
            cadastrosToolStripMenuItem.Name = "cadastrosToolStripMenuItem";
            cadastrosToolStripMenuItem.Size = new Size(79, 20);
            cadastrosToolStripMenuItem.Text = "CADASTRO";
            // 
            // clienteToolStripMenuItem
            // 
            clienteToolStripMenuItem.Name = "clienteToolStripMenuItem";
            clienteToolStripMenuItem.Size = new Size(180, 22);
            clienteToolStripMenuItem.Text = "Cliente";
            // 
            // produtoToolStripMenuItem
            // 
            produtoToolStripMenuItem.Name = "produtoToolStripMenuItem";
            produtoToolStripMenuItem.Size = new Size(180, 22);
            produtoToolStripMenuItem.Text = "Produto";
            produtoToolStripMenuItem.Click += produtoToolStripMenuItem_Click;
            // 
            // fornecedirToolStripMenuItem
            // 
            fornecedirToolStripMenuItem.Name = "fornecedirToolStripMenuItem";
            fornecedirToolStripMenuItem.Size = new Size(180, 22);
            fornecedirToolStripMenuItem.Text = "Fornecedor";
            // 
            // usuárioToolStripMenuItem
            // 
            usuárioToolStripMenuItem.Name = "usuárioToolStripMenuItem";
            usuárioToolStripMenuItem.Size = new Size(180, 22);
            usuárioToolStripMenuItem.Text = "Usuário";
            // 
            // mOVIMENTAÇÕESToolStripMenuItem
            // 
            mOVIMENTAÇÕESToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { vendaToolStripMenuItem });
            mOVIMENTAÇÕESToolStripMenuItem.Name = "mOVIMENTAÇÕESToolStripMenuItem";
            mOVIMENTAÇÕESToolStripMenuItem.Size = new Size(117, 20);
            mOVIMENTAÇÕESToolStripMenuItem.Text = "MOVIMENTAÇÕES";
            // 
            // vendaToolStripMenuItem
            // 
            vendaToolStripMenuItem.Name = "vendaToolStripMenuItem";
            vendaToolStripMenuItem.Size = new Size(180, 22);
            vendaToolStripMenuItem.Text = "Venda";
            // 
            // rELATÓRIOSToolStripMenuItem
            // 
            rELATÓRIOSToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { históricoDeVendasToolStripMenuItem });
            rELATÓRIOSToolStripMenuItem.Name = "rELATÓRIOSToolStripMenuItem";
            rELATÓRIOSToolStripMenuItem.Size = new Size(84, 20);
            rELATÓRIOSToolStripMenuItem.Text = "RELATÓRIOS";
            // 
            // históricoDeVendasToolStripMenuItem
            // 
            históricoDeVendasToolStripMenuItem.Name = "históricoDeVendasToolStripMenuItem";
            históricoDeVendasToolStripMenuItem.Size = new Size(180, 22);
            históricoDeVendasToolStripMenuItem.Text = "Histórico de vendas";
            // 
            // sAIRToolStripMenuItem
            // 
            sAIRToolStripMenuItem.Name = "sAIRToolStripMenuItem";
            sAIRToolStripMenuItem.Size = new Size(43, 20);
            sAIRToolStripMenuItem.Text = "SAIR";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "MENU";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem cadastrosToolStripMenuItem;
        private ToolStripMenuItem clienteToolStripMenuItem;
        private ToolStripMenuItem produtoToolStripMenuItem;
        private ToolStripMenuItem fornecedirToolStripMenuItem;
        private ToolStripMenuItem usuárioToolStripMenuItem;
        private ToolStripMenuItem mOVIMENTAÇÕESToolStripMenuItem;
        private ToolStripMenuItem vendaToolStripMenuItem;
        private ToolStripMenuItem rELATÓRIOSToolStripMenuItem;
        private ToolStripMenuItem históricoDeVendasToolStripMenuItem;
        private ToolStripMenuItem sAIRToolStripMenuItem;
    }
}
