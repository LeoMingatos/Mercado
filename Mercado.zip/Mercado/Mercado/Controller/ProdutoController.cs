﻿using Mercado.Model;
using Mercado.Services;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;

namespace Mercado.Controller
{
    public class ProdutoController
    {
        private readonly DataBaseServices dataBase = new DataBaseServices();

        // INSERT
        public int Inserir(Produto produto)
        {
            string query = @"INSERT INTO Produto (Nome, Preco, Estoque, IdFornecedor)
                             VALUES (@Nome, @Preco, @Estoque, @IdFornecedor)";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@Nome", produto.Nome);
            command.Parameters.AddWithValue("@Preco", produto.Preco);
            command.Parameters.AddWithValue("@Estoque", produto.Estoque);
            command.Parameters.AddWithValue("@IdFornecedor", produto.IdFornecedor);

            return dataBase.ExecuteSQL(command);
        }

        // UPDATE
        public int Alterar(Produto produto)
        {
            string query = @"UPDATE Produto
                             SET Nome = @Nome,
                                 Preco = @Preco,
                                 Estoque = @Estoque,
                                 IdFornecedor = @IdFornecedor
                             WHERE IdProduto = @IdProduto";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@Nome", produto.Nome);
            command.Parameters.AddWithValue("@Preco", produto.Preco);
            command.Parameters.AddWithValue("@Estoque", produto.Estoque);
            command.Parameters.AddWithValue("@IdFornecedor", produto.IdFornecedor);
            command.Parameters.AddWithValue("@IdProduto", produto.IdProduto);

            return dataBase.ExecuteSQL(command);
        }

        // DELETE
        public int Excluir(int idProduto)
        {
            string query = "DELETE FROM Produto WHERE IdProduto = @IdProduto";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdProduto", idProduto);

            return dataBase.ExecuteSQL(command);
        }

        // SELECT por ID
        public Produto GetById(int idProduto)
        {
            string query = "SELECT * FROM Produto WHERE IdProduto = @IdProduto";
            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdProduto", idProduto);

            DataTable table = dataBase.GetDataTable(command);
            if (table.Rows.Count == 0)
                return null;

            DataRow row = table.Rows[0];
            return new Produto
            {
                IdProduto = Convert.ToInt32(row["IdProduto"]),
                Nome = row["Nome"].ToString(),
                Preco = Convert.ToDecimal(row["Preco"]),
                Estoque = Convert.ToInt32(row["Estoque"]),
                IdFornecedor = Convert.ToInt32(row["IdFornecedor"])
            };
        }

        // SELECT todos
        public List<Produto> GetAll()
        {
            string query = "SELECT * FROM Produto ORDER BY Nome";
            SqlCommand command = new SqlCommand(query);

            DataTable table = dataBase.GetDataTable(command);
            List<Produto> produtos = new List<Produto>();

            foreach (DataRow row in table.Rows)
            {
                produtos.Add(new Produto
                {
                    IdProduto = Convert.ToInt32(row["IdProduto"]),
                    Nome = row["Nome"].ToString(),
                    Preco = Convert.ToDecimal(row["Preco"]),
                    Estoque = Convert.ToInt32(row["Estoque"]),
                    IdFornecedor = Convert.ToInt32(row["IdFornecedor"])
                });
            }

            return produtos;
        }

        // SELECT por Nome
        public List<Produto> GetByNome(string nome)
        {
            string query = "SELECT * FROM Produto WHERE Nome LIKE @Nome";
            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@Nome", "%" + nome + "%");

            DataTable table = dataBase.GetDataTable(command);
            List<Produto> produtos = new List<Produto>();

            foreach (DataRow row in table.Rows)
            {
                produtos.Add(new Produto
                {
                    IdProduto = Convert.ToInt32(row["IdProduto"]),
                    Nome = row["Nome"].ToString(),
                    Preco = Convert.ToDecimal(row["Preco"]),
                    Estoque = Convert.ToInt32(row["Estoque"]),
                    IdFornecedor = Convert.ToInt32(row["IdFornecedor"])
                });
            }

            return produtos;
        }
    }
}
