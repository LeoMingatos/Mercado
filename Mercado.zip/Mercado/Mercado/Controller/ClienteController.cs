﻿using Mercado.Model;
using Mercado.Services;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;

namespace Mercado.Controller
{
    public class ClienteController
    {
        // Acesso ao banco
        DataBaseServices dataBase = new DataBaseServices();

        // INSERT
        public int Inserir(Cliente cliente)
        {
            string query =
                "INSERT INTO Cliente (Nome, CPF, Telefone, Email) " +
                "VALUES (@Nome, @CPF, @Telefone, @Email)";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@Nome", cliente.Nome);
            command.Parameters.AddWithValue("@CPF", cliente.CPF);
            command.Parameters.AddWithValue("@Telefone", cliente.Telefone);
            command.Parameters.AddWithValue("@Email", cliente.Email);

            return dataBase.ExecuteSQL(command);
        }

        // UPDATE
        public int Alterar(Cliente cliente)
        {
            string query =
                "UPDATE Cliente SET " +
                "Nome = @Nome, " +
                "CPF = @CPF, " +
                "Telefone = @Telefone, " +
                "Email = @Email " +
                "WHERE IdCliente = @IdCliente";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@Nome", cliente.Nome);
            command.Parameters.AddWithValue("@CPF", cliente.CPF);
            command.Parameters.AddWithValue("@Telefone", cliente.Telefone);
            command.Parameters.AddWithValue("@Email", cliente.Email);
            command.Parameters.AddWithValue("@IdCliente", cliente.IdCliente);

            return dataBase.ExecuteSQL(command);
        }

        // DELETE
        public int Excluir(int idCliente)
        {
            string query =
                "DELETE FROM Cliente WHERE IdCliente = @IdCliente";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdCliente", idCliente);

            return dataBase.ExecuteSQL(command);
        }

        // SELECT por ID
        public Cliente GetById(int idCliente)
        {
            string query =
                "SELECT * FROM Cliente WHERE IdCliente = @IdCliente";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdCliente", idCliente);

            DataTable dataTable = dataBase.GetDataTable(command);

            if (dataTable.Rows.Count > 0)
            {
                DataRow row = dataTable.Rows[0];

                Cliente cliente = new Cliente();
                cliente.IdCliente = Convert.ToInt32(row["IdCliente"]);
                cliente.Nome = row["Nome"].ToString();
                cliente.CPF = row["CPF"].ToString();
                cliente.Telefone = row["Telefone"].ToString();
                cliente.Email = row["Email"].ToString();

                return cliente;
            }

            return null;
        }

        // SELECT com filtro
        public List<Cliente> GetByFilter(string filtro = "")
        {
            string query = "SELECT * FROM Cliente ";

            if (!string.IsNullOrEmpty(filtro))
                query += "WHERE " + filtro + " ";

            query += "ORDER BY Nome";

            SqlCommand command = new SqlCommand(query);
            DataTable dataTable = dataBase.GetDataTable(command);

            List<Cliente> clientes = new List<Cliente>();

            foreach (DataRow row in dataTable.Rows)
            {
                Cliente cliente = new Cliente();
                cliente.IdCliente = Convert.ToInt32(row["IdCliente"]);
                cliente.Nome = row["Nome"].ToString();
                cliente.CPF = row["CPF"].ToString();
                cliente.Telefone = row["Telefone"].ToString();
                cliente.Email = row["Email"].ToString();

                clientes.Add(cliente);
            }

            return clientes;
        }

        // SELECT todos
        public List<Cliente> GetAll()
        {
            return GetByFilter();
        }

        // SELECT por nome
        public List<Cliente> GetByName(string value)
        {
            return GetByFilter("Nome LIKE '%" + value + "%'");
        }

        // SELECT por CPF
        public List<Cliente> GetByCPF(string value)
        {
            return GetByFilter("CPF = '" + value + "'");
        }
    }
}
