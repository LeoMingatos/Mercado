﻿using Mercado.Model;
using Mercado.Services;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;

namespace Mercado.Controller
{
    public class FornecedorController
    {
        // Acesso ao banco
        DataBaseServices dataBase = new DataBaseServices();

        // INSERT
        public int Inserir(Fornecedor fornecedor)
        {
            string query = @"INSERT INTO Fornecedor (RazaoSocial, CNPJ, Telefone, Email)
                             VALUES (@RazaoSocial, @CNPJ, @Telefone, @Email)";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@RazaoSocial", fornecedor.RazaoSocial);
            command.Parameters.AddWithValue("@CNPJ", fornecedor.CNPJ);
            command.Parameters.AddWithValue("@Telefone", fornecedor.Telefone);
            command.Parameters.AddWithValue("@Email", fornecedor.Email);

            return dataBase.ExecuteSQL(command);
        }

        // UPDATE
        public int Alterar(Fornecedor fornecedor)
        {
            string query = @"UPDATE Fornecedor
                             SET RazaoSocial = @RazaoSocial,
                                 CNPJ = @CNPJ,
                                 Telefone = @Telefone,
                                 Email = @Email
                             WHERE IdFornecedor = @IdFornecedor";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@RazaoSocial", fornecedor.RazaoSocial);
            command.Parameters.AddWithValue("@CNPJ", fornecedor.CNPJ);
            command.Parameters.AddWithValue("@Telefone", fornecedor.Telefone);
            command.Parameters.AddWithValue("@Email", fornecedor.Email);
            command.Parameters.AddWithValue("@IdFornecedor", fornecedor.IdFornecedor);

            return dataBase.ExecuteSQL(command);
        }

        // DELETE
        public int Excluir(int idFornecedor)
        {
            string query = "DELETE FROM Fornecedor WHERE IdFornecedor = @IdFornecedor";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdFornecedor", idFornecedor);

            return dataBase.ExecuteSQL(command);
        }

        // SELECT por ID
        public Fornecedor GetById(int idFornecedor)
        {
            string query = "SELECT * FROM Fornecedor WHERE IdFornecedor = @IdFornecedor";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdFornecedor", idFornecedor);

            DataTable dataTable = dataBase.GetDataTable(command);

            if (dataTable.Rows.Count > 0)
            {
                DataRow row = dataTable.Rows[0];

                Fornecedor fornecedor = new Fornecedor
                {
                    IdFornecedor = Convert.ToInt32(row["IdFornecedor"]),
                    RazaoSocial = row["RazaoSocial"].ToString(),
                    CNPJ = row["CNPJ"].ToString(),
                    Telefone = row["Telefone"].ToString(),
                    Email = row["Email"].ToString()
                };

                return fornecedor;
            }

            return null;
        }

        // SELECT com filtro
        public List<Fornecedor> GetByFilter(string filtro = "")
        {
            string query = "SELECT * FROM Fornecedor ";

            if (!string.IsNullOrEmpty(filtro))
                query += "WHERE " + filtro + " ";

            query += "ORDER BY RazaoSocial";

            SqlCommand command = new SqlCommand(query);
            DataTable dataTable = dataBase.GetDataTable(command);

            List<Fornecedor> fornecedores = new List<Fornecedor>();

            foreach (DataRow row in dataTable.Rows)
            {
                Fornecedor fornecedor = new Fornecedor
                {
                    IdFornecedor = Convert.ToInt32(row["IdFornecedor"]),
                    RazaoSocial = row["RazaoSocial"].ToString(),
                    CNPJ = row["CNPJ"].ToString(),
                    Telefone = row["Telefone"].ToString(),
                    Email = row["Email"].ToString()
                };

                fornecedores.Add(fornecedor);
            }

            return fornecedores;
        }

        // SELECT todos
        public List<Fornecedor> GetAll()
        {
            return GetByFilter();
        }

        // SELECT por Razão Social
        public List<Fornecedor> GetByRazaoSocial(string value)
        {
            return GetByFilter("RazaoSocial LIKE '%" + value + "%'");
        }

        // SELECT por CNPJ
        public List<Fornecedor> GetByCNPJ(string value)
        {
            return GetByFilter("CNPJ = '" + value + "'");
        }
    }
}
