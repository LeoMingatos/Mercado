﻿using Mercado.Model;
using Mercado.Services;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Mercado.Controller
{
    public class UsuarioController
    {
        private readonly DataBaseServices db = new DataBaseServices();

        // CREATE - Inserir novo usuário
        public int Inserir(Usuario usuario)
        {
            string query = @"
                INSERT INTO Usuario (Nome, Login, Senha, NivelAcesso)
                VALUES (@Nome, @Login, @Senha, @NivelAcesso)";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@Nome", usuario.Nome);
            command.Parameters.AddWithValue("@Login", usuario.Login);
            command.Parameters.AddWithValue("@Senha", usuario.Senha);
            command.Parameters.AddWithValue("@NivelAcesso", usuario.NivelAcesso);

            return db.ExecuteSQL(command);
        }

        // UPDATE - Alterar usuário existente
        public int Alterar(Usuario usuario)
        {
            string query = @"
                UPDATE Usuario SET 
                    Nome = @Nome,
                    Login = @Login,
                    Senha = @Senha,
                    NivelAcesso = @NivelAcesso
                WHERE IdUsuario = @IdUsuario";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdUsuario", usuario.IdUsuario);
            command.Parameters.AddWithValue("@Nome", usuario.Nome);
            command.Parameters.AddWithValue("@Login", usuario.Login);
            command.Parameters.AddWithValue("@Senha", usuario.Senha);
            command.Parameters.AddWithValue("@NivelAcesso", usuario.NivelAcesso);

            return db.ExecuteSQL(command);
        }

        // DELETE - Excluir usuário
        public int Excluir(int idUsuario)
        {
            string query = "DELETE FROM Usuario WHERE IdUsuario = @IdUsuario";
            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdUsuario", idUsuario);

            return db.ExecuteSQL(command);
        }

        // READ - Buscar todos
        public DataTable GetAll()
        {
            string query = "SELECT * FROM Usuario ORDER BY Nome";
            SqlCommand command = new SqlCommand(query);
            return db.GetDataTable(command);
        }

        // READ - Buscar por nome
        public DataTable GetByNome(string nome)
        {
            string query = "SELECT * FROM Usuario WHERE Nome LIKE @Nome ORDER BY Nome";
            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@Nome", "%" + nome + "%");
            return db.GetDataTable(command);
        }

        // READ - Buscar por login (para login ou verificação)
        public DataTable GetByLogin(string login)
        {
            string query = "SELECT * FROM Usuario WHERE Login = @Login";
            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@Login", login);
            return db.GetDataTable(command);
        }
    }
}
