namespace Mercado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void produtoToolStripMenuItem_Click(object sender, EventArgs e)
        {
          //  TelaSelecaoProdutos form = new TelaSelecaoProdutos();
          //  Form.ShowDialog();
        }
    }
}
