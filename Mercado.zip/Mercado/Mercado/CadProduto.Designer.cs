﻿using Mercado.Controller;
using Mercado.Model;

namespace Mercado
{

     public partial class CadProduto : Form
    {
        ProdutoController produtoController = new ProdutoController();
        FornecedorController fornecedorController = new FornecedorController();

        

        private void CarregarFornecedores()
        {
            cmbFornecedor.DataSource = fornecedorController.GetAll();
            cmbFornecedor.DisplayMember = "RazaoSocial";
            cmbFornecedor.ValueMember = "IdFornecedor";
        }

        private void AtualizarGrid()
        {
            dgvProdutos.DataSource = produtoController.GetAll();
        }

        private void LimparCampos()
        {
            txtId.Clear();
            txtNome.Clear();
            txtPreco.Clear();
            txtEstoque.Clear();
            cmbFornecedor.SelectedIndex = -1;
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Preencha o nome do produto!");
                return;
            }

            Produto produto = new Produto
            {
                Nome = txtNome.Text,
                Preco = decimal.Parse(txtPreco.Text),
                Estoque = int.Parse(txtEstoque.Text),
                IdFornecedor = (int)cmbFornecedor.SelectedValue
            };

            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                produtoController.Inserir(produto);
                MessageBox.Show("Produto cadastrado com sucesso!");
            }
            else
            {
                produto.IdProduto = Convert.ToInt32(txtId.Text);
                produtoController.Alterar(produto);
                MessageBox.Show("Produto atualizado com sucesso!");
            }

            AtualizarGrid();
            LimparCampos();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                MessageBox.Show("Selecione um produto para excluir!");
                return;
            }

            int id = Convert.ToInt32(txtId.Text);
            produtoController.Excluir(id);
            MessageBox.Show("Produto excluído com sucesso!");
            AtualizarGrid();
            LimparCampos();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            dgvProdutos.DataSource = produtoController.GetByNome(txtNome.Text);
        }

        private void dgvProdutos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvProdutos.Rows[e.RowIndex];
                txtId.Text = row.Cells["IdProduto"].Value.ToString();
                txtNome.Text = row.Cells["Nome"].Value.ToString();
                txtPreco.Text = row.Cells["Preco"].Value.ToString();
                txtEstoque.Text = row.Cells["Estoque"].Value.ToString();
                cmbFornecedor.SelectedValue = row.Cells["IdFornecedor"].Value;
            }
        }

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtId = new TextBox();
            txtNome = new TextBox();
            txtPreco = new TextBox();
            txtEstoque = new TextBox();
            cmbFornecedor = new ComboBox();
            btnNovo = new Button();
            btnSalvar = new Button();
            btnExcluir = new Button();
            btnPesquisar = new Button();
            dgvProdutos = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvProdutos).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(17, 15);
            label1.Name = "label1";
            label1.Size = new Size(21, 15);
            label1.TabIndex = 0;
            label1.Text = "ID:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(17, 43);
            label2.Name = "label2";
            label2.Size = new Size(43, 15);
            label2.TabIndex = 1;
            label2.Text = "Nome:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(172, 15);
            label3.Name = "label3";
            label3.Size = new Size(40, 15);
            label3.TabIndex = 2;
            label3.Text = "Preço:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(169, 46);
            label4.Name = "label4";
            label4.Size = new Size(52, 15);
            label4.TabIndex = 3;
            label4.Text = "Estoque:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(331, 15);
            label5.Name = "label5";
            label5.Size = new Size(70, 15);
            label5.TabIndex = 4;
            label5.Text = "Fornecedor:";
            // 
            // txtId
            // 
            txtId.Location = new Point(63, 12);
            txtId.Name = "txtId";
            txtId.ReadOnly = true;
            txtId.Size = new Size(100, 23);
            txtId.TabIndex = 5;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(63, 43);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(100, 23);
            txtNome.TabIndex = 6;
            // 
            // txtPreco
            // 
            txtPreco.Location = new Point(218, 17);
            txtPreco.Name = "txtPreco";
            txtPreco.Size = new Size(100, 23);
            txtPreco.TabIndex = 7;
            // 
            // txtEstoque
            // 
            txtEstoque.Location = new Point(218, 43);
            txtEstoque.Name = "txtEstoque";
            txtEstoque.Size = new Size(100, 23);
            txtEstoque.TabIndex = 8;
            // 
            // cmbFornecedor
            // 
            cmbFornecedor.FormattingEnabled = true;
            cmbFornecedor.Location = new Point(407, 12);
            cmbFornecedor.Name = "cmbFornecedor";
            cmbFornecedor.Size = new Size(121, 23);
            cmbFornecedor.TabIndex = 9;
            // 
            // btnNovo
            // 
            btnNovo.Location = new Point(28, 302);
            btnNovo.Name = "btnNovo";
            btnNovo.Size = new Size(75, 23);
            btnNovo.TabIndex = 10;
            btnNovo.Text = "NOVO";
            btnNovo.UseVisualStyleBackColor = true;
            // 
            // btnSalvar
            // 
            btnSalvar.Location = new Point(191, 302);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(75, 23);
            btnSalvar.TabIndex = 11;
            btnSalvar.Text = "SALVAR";
            btnSalvar.UseVisualStyleBackColor = true;
            // 
            // btnExcluir
            // 
            btnExcluir.Location = new Point(531, 302);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(75, 23);
            btnExcluir.TabIndex = 12;
            btnExcluir.Text = "EXCLUIR";
            btnExcluir.UseVisualStyleBackColor = true;
            // 
            // btnPesquisar
            // 
            btnPesquisar.Location = new Point(640, 302);
            btnPesquisar.Name = "btnPesquisar";
            btnPesquisar.Size = new Size(75, 23);
            btnPesquisar.TabIndex = 13;
            btnPesquisar.Text = "PESQUISAR";
            btnPesquisar.UseVisualStyleBackColor = true;
            // 
            // dgvProdutos
            // 
            dgvProdutos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProdutos.Location = new Point(17, 109);
            dgvProdutos.Name = "dgvProdutos";
            dgvProdutos.Size = new Size(732, 150);
            dgvProdutos.TabIndex = 14;
            // 
            // CadProduto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgvProdutos);
            Controls.Add(btnPesquisar);
            Controls.Add(btnExcluir);
            Controls.Add(btnSalvar);
            Controls.Add(btnNovo);
            Controls.Add(cmbFornecedor);
            Controls.Add(txtEstoque);
            Controls.Add(txtPreco);
            Controls.Add(txtNome);
            Controls.Add(txtId);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "CadProduto";
            Text = "CadProduto";
            ((System.ComponentModel.ISupportInitialize)dgvProdutos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtId;
        private TextBox txtNome;
        private TextBox txtPreco;
        private TextBox txtEstoque;
        private ComboBox cmbFornecedor;
        private Button btnNovo;
        private Button btnSalvar;
        private Button btnExcluir;
        private Button btnPesquisar;
        private DataGridView dgvProdutos;
    }
}