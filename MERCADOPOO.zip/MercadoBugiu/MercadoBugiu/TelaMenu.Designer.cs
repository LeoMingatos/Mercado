﻿using System.Drawing;
using System.Windows.Forms;

namespace MERCADOPOO
{
    partial class TelaMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            cadastrosToolStripMenuItem = new ToolStripMenuItem();
            clienteToolStripMenuItem = new ToolStripMenuItem();
            produtoToolStripMenuItem = new ToolStripMenuItem();
            fornecedirToolStripMenuItem = new ToolStripMenuItem();
            usuárioToolStripMenuItem = new ToolStripMenuItem();
            mOVIMENTAÇÕESToolStripMenuItem = new ToolStripMenuItem();
            vendaToolStripMenuItem = new ToolStripMenuItem();
            entradaToolStripMenuItem = new ToolStripMenuItem();
            rELATÓRIOSToolStripMenuItem = new ToolStripMenuItem();
            históricoDeVendasToolStripMenuItem = new ToolStripMenuItem();
            estoqueToolStripMenuItem = new ToolStripMenuItem();
            sAIRToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = Color.MidnightBlue;
            menuStrip1.Items.AddRange(new ToolStripItem[] { cadastrosToolStripMenuItem, mOVIMENTAÇÕESToolStripMenuItem, rELATÓRIOSToolStripMenuItem, sAIRToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 2;
            menuStrip1.Text = "menuStrip1";
            // 
            // cadastrosToolStripMenuItem
            // 
            cadastrosToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { clienteToolStripMenuItem, produtoToolStripMenuItem, fornecedirToolStripMenuItem, usuárioToolStripMenuItem });
            cadastrosToolStripMenuItem.ForeColor = Color.CornflowerBlue;
            cadastrosToolStripMenuItem.Name = "cadastrosToolStripMenuItem";
            cadastrosToolStripMenuItem.Size = new Size(80, 20);
            cadastrosToolStripMenuItem.Text = "CADASTRO";
            // 
            // clienteToolStripMenuItem
            // 
            clienteToolStripMenuItem.BackColor = Color.MidnightBlue;
            clienteToolStripMenuItem.ForeColor = Color.CornflowerBlue;
            clienteToolStripMenuItem.Name = "clienteToolStripMenuItem";
            clienteToolStripMenuItem.Size = new Size(134, 22);
            clienteToolStripMenuItem.Text = "Cliente";
            clienteToolStripMenuItem.Click += clienteToolStripMenuItem_Click;
            // 
            // produtoToolStripMenuItem
            // 
            produtoToolStripMenuItem.BackColor = Color.MidnightBlue;
            produtoToolStripMenuItem.ForeColor = Color.CornflowerBlue;
            produtoToolStripMenuItem.Name = "produtoToolStripMenuItem";
            produtoToolStripMenuItem.Size = new Size(134, 22);
            produtoToolStripMenuItem.Text = "Produto";
            produtoToolStripMenuItem.Click += produtoToolStripMenuItem_Click;
            // 
            // fornecedirToolStripMenuItem
            // 
            fornecedirToolStripMenuItem.BackColor = Color.MidnightBlue;
            fornecedirToolStripMenuItem.ForeColor = Color.CornflowerBlue;
            fornecedirToolStripMenuItem.Name = "fornecedirToolStripMenuItem";
            fornecedirToolStripMenuItem.Size = new Size(134, 22);
            fornecedirToolStripMenuItem.Text = "Fornecedor";
            fornecedirToolStripMenuItem.Click += fornecedirToolStripMenuItem_Click;
            // 
            // usuárioToolStripMenuItem
            // 
            usuárioToolStripMenuItem.BackColor = Color.MidnightBlue;
            usuárioToolStripMenuItem.ForeColor = Color.CornflowerBlue;
            usuárioToolStripMenuItem.Name = "usuárioToolStripMenuItem";
            usuárioToolStripMenuItem.Size = new Size(134, 22);
            usuárioToolStripMenuItem.Text = "Usuário";
            usuárioToolStripMenuItem.Click += usuárioToolStripMenuItem_Click;
            // 
            // mOVIMENTAÇÕESToolStripMenuItem
            // 
            mOVIMENTAÇÕESToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { vendaToolStripMenuItem, entradaToolStripMenuItem });
            mOVIMENTAÇÕESToolStripMenuItem.ForeColor = Color.CornflowerBlue;
            mOVIMENTAÇÕESToolStripMenuItem.Name = "mOVIMENTAÇÕESToolStripMenuItem";
            mOVIMENTAÇÕESToolStripMenuItem.Size = new Size(118, 20);
            mOVIMENTAÇÕESToolStripMenuItem.Text = "MOVIMENTAÇÕES";
            // 
            // vendaToolStripMenuItem
            // 
            vendaToolStripMenuItem.BackColor = Color.MidnightBlue;
            vendaToolStripMenuItem.ForeColor = Color.CornflowerBlue;
            vendaToolStripMenuItem.Name = "vendaToolStripMenuItem";
            vendaToolStripMenuItem.Size = new Size(114, 22);
            vendaToolStripMenuItem.Text = "Venda";
            vendaToolStripMenuItem.Click += vendaToolStripMenuItem_Click;
            // 
            // entradaToolStripMenuItem
            // 
            entradaToolStripMenuItem.BackColor = Color.MidnightBlue;
            entradaToolStripMenuItem.ForeColor = Color.CornflowerBlue;
            entradaToolStripMenuItem.Name = "entradaToolStripMenuItem";
            entradaToolStripMenuItem.Size = new Size(114, 22);
            entradaToolStripMenuItem.Text = "Entrada";
            entradaToolStripMenuItem.Click += entradaToolStripMenuItem_Click;
            // 
            // rELATÓRIOSToolStripMenuItem
            // 
            rELATÓRIOSToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { históricoDeVendasToolStripMenuItem, estoqueToolStripMenuItem });
            rELATÓRIOSToolStripMenuItem.ForeColor = Color.CornflowerBlue;
            rELATÓRIOSToolStripMenuItem.Name = "rELATÓRIOSToolStripMenuItem";
            rELATÓRIOSToolStripMenuItem.Size = new Size(85, 20);
            rELATÓRIOSToolStripMenuItem.Text = "RELATÓRIOS";
            // 
            // históricoDeVendasToolStripMenuItem
            // 
            históricoDeVendasToolStripMenuItem.BackColor = Color.MidnightBlue;
            históricoDeVendasToolStripMenuItem.ForeColor = Color.CornflowerBlue;
            históricoDeVendasToolStripMenuItem.Name = "históricoDeVendasToolStripMenuItem";
            históricoDeVendasToolStripMenuItem.Size = new Size(178, 22);
            históricoDeVendasToolStripMenuItem.Text = "Histórico de vendas";
            históricoDeVendasToolStripMenuItem.Click += históricoDeVendasToolStripMenuItem_Click;
            // 
            // estoqueToolStripMenuItem
            // 
            estoqueToolStripMenuItem.BackColor = Color.MidnightBlue;
            estoqueToolStripMenuItem.ForeColor = Color.CornflowerBlue;
            estoqueToolStripMenuItem.Name = "estoqueToolStripMenuItem";
            estoqueToolStripMenuItem.Size = new Size(178, 22);
            estoqueToolStripMenuItem.Text = "Estoque";
            estoqueToolStripMenuItem.Click += estoqueToolStripMenuItem_Click;
            // 
            // sAIRToolStripMenuItem
            // 
            sAIRToolStripMenuItem.ForeColor = Color.CornflowerBlue;
            sAIRToolStripMenuItem.Name = "sAIRToolStripMenuItem";
            sAIRToolStripMenuItem.Size = new Size(43, 20);
            sAIRToolStripMenuItem.Text = "SAIR";
            sAIRToolStripMenuItem.Click += sAIRToolStripMenuItem_Click;
            // 
            // TelaMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MidnightBlue;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            Name = "TelaMenu";
            Text = "TelaMenu";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem cadastrosToolStripMenuItem;
        private ToolStripMenuItem clienteToolStripMenuItem;
        private ToolStripMenuItem produtoToolStripMenuItem;
        private ToolStripMenuItem fornecedirToolStripMenuItem;
        private ToolStripMenuItem usuárioToolStripMenuItem;
        private ToolStripMenuItem mOVIMENTAÇÕESToolStripMenuItem;
        private ToolStripMenuItem vendaToolStripMenuItem;
        private ToolStripMenuItem entradaToolStripMenuItem;
        private ToolStripMenuItem rELATÓRIOSToolStripMenuItem;
        private ToolStripMenuItem históricoDeVendasToolStripMenuItem;
        private ToolStripMenuItem estoqueToolStripMenuItem;
        private ToolStripMenuItem sAIRToolStripMenuItem;
    }
}