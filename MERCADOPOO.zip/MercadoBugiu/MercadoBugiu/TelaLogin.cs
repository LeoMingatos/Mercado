﻿using MERCADOPOO.Controller;
using MERCADOPOO.Model;
using MERCADOPOO.Util; // para gerenciar o usuário logado
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MERCADOPOO
{
    // Formulário principal de Login do sistema.
    public partial class TelaLogin : Form
    {
        // Instância do Controller para validação de credenciais no banco.
        private readonly UsuarioController usuarioController = new UsuarioController();

        public TelaLogin()
        {
            InitializeComponent();
            this.Resize += new EventHandler(TelaLogin_Resize);
            this.Load += new EventHandler(TelaLogin_Load);
            CentralizarPainel();
        }

        private void CentralizarPainel()
        {
            // Verifica se o painel existe 
            if (this.pnlContainer != null)
            {
                // Calcula a nova posição X (horizontal)
                // (Largura do formulário - Largura do painel) / 2
                int x = (this.ClientSize.Width - pnlContainer.Width) / 2;

                // Calcula a nova posição Y (vertical)
                // (Altura do formulário - Altura do painel) / 2
                int y = (this.ClientSize.Height - pnlContainer.Height) / 2;

                // Atribui a nova posição ao painel
                pnlContainer.Location = new Point(x, y);
            }
        }

        // --- EVENTOS DE INTERAÇÃO ---

        // Chamado sempre que o Form é redimensionado
        private void TelaLogin_Resize(object sender, EventArgs e)
        {
            CentralizarPainel();
        }

        // Chamado ao carregar o Form pela primeira vez
        private void TelaLogin_Load(object sender, EventArgs e)
        {
            CentralizarPainel();
        }

        // Disparado ao pressionar uma tecla no campo de Login ou Senha (se conectado).
        // Chama a ação principal de Entrar se a tecla for ENTER.
        private void btnEntrar_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                // Chama a lógica principal de login
                btnEntrar_Click(sender, e);
                e.Handled = true; // Impede que o sistema processe a tecla ENTER novamente 
            }
        }

        // Botão ENTRAR 
        private void btnEntrar_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string senha = txtSenha.Text;

            // Validação de campos vazios
            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(senha))
            {
                MessageBox.Show("Preencha Login e Senha.", "Atenção");
                return;
            }

            try
            {
                // Valida o usuário no banco de dados
                Usuario usuario = usuarioController.ValidarLogin(login, senha);

                if (usuario != null)
                {
                    // SUCESSO: Inicia a Sessão 
                    SessaoAtual.IniciarSessao(usuario.IdUsuario, usuario.Nome);

                    // Abre o Menu Principal
                    this.Hide(); // Esconde a tela de login

                    //Abre a tela de Menu Principal
                    TelaMenu principal = new TelaMenu();
                    principal.Show();
                }
                else
                {
                    // FALHA: Credenciais inválidas
                    MessageBox.Show("Credenciais inválidas. Verifique seu login e senha.", "Falha no Login");
                    txtLogin.Focus();
                }
            }
            catch (Exception ex)
            {
                // Trata erros de conexão ou de sistema
                MessageBox.Show($"Erro ao conectar ou validar o login: {ex.Message}", "Erro de Sistema");
            }
        }

       
    }
}