﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MERCADOPOO.Util
{
    // Esta classe armazena dados do usuário que está logado no sistema.
    
    public static class SessaoAtual
    {
        // Variável: ID do usuário logado no momento. (Só pode ser modificado dentro desta classe).
        public static int IdUsuarioLogado { get; private set; }

        // Variável: Nome do usuário logado.
        public static string NomeUsuarioLogado { get; private set; }

        // Variável: Flag booleana que indica se há um usuário ativo.
        public static bool EstaLogado { get; private set; }

        
        // Inicia a sessão após um login bem-sucedido.
        
        public static void IniciarSessao(int idUsuario, string nomeUsuario)
        {
            IdUsuarioLogado = idUsuario;
            NomeUsuarioLogado = nomeUsuario;
            EstaLogado = true; // Define o status como logado
        }

        
        // Usada quando o usuário desloga para limpar os dados de segurança da sessão.
       
        public static void EncerrarSessao()
        {
            IdUsuarioLogado = 0;      // Reseta o ID
            NomeUsuarioLogado = null; // Limpa o nome
            EstaLogado = false;       // Define o status como deslogado
        }
    }
}