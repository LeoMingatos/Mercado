﻿using MERCADOPOO.Controller;
using MERCADOPOO.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MERCADOPOO
{
    // Formulário para pesquisar e selecionar um único produto
    public partial class PesquisaProduto : Form
    {
        // Controller para acesso aos dados do produto
        private ProdutoController controller = new ProdutoController();

        // Propriedade para armazenar o objeto Produto selecionado para retorno.
        public Produto ProdutoSelecionado { get; private set; }

        public PesquisaProduto()
        {
            InitializeComponent();
            CarregarTodosProdutos(); // Carrega os produtos ao iniciar
        }

        // Carrega a lista completa de produtos na DataGridView.
        private void CarregarTodosProdutos()
        {
            dgvResultados.DataSource = controller.GetAll();
        }

        // --- LÓGICA DE PESQUISA E SELEÇÃO ---

        // Botão Buscar
        // //Pesquisa por Nome, Marca ou ID.
        private void btnBuscar_Click(object sender, EventArgs e)
        {
           string nomeBusca = txtPesquisaNome.Text.Trim();

            if (string.IsNullOrWhiteSpace(nomeBusca))
            {
                CarregarTodosProdutos(); // Se vazio, recarrega tudo
                return;
            }

            // Chama o método que busca em múltiplas colunas (Nome, Marca ou ID)
            dgvResultados.DataSource = controller.GetEstoqueComFiltro(nomeBusca);

            if (dgvResultados.Rows.Count == 0)
            {
                MessageBox.Show($"Nenhum produto ou marca encontrado com o termo '{nomeBusca}'.", "Busca Vazia");
            }
        }

        // Duplo clique na linha (para agilizar a seleção)
        private void dgvResultados_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            SelecionarProduto();
        }

        // Clique no botão Selecionar
        private void btnSelecionar_Click(object sender, EventArgs e)
        {
            SelecionarProduto();
        }

        // Lógica principal que pega o produto selecionado e define o retorno.
        private void SelecionarProduto()
        {
            // Verifica se há uma linha selecionada
            if (dgvResultados.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecione um produto na lista.");
                return;
            }

            // Pega a linha selecionada
            DataGridViewRow row = dgvResultados.SelectedRows[0];

            // Pega o ID do produto da célula (código de barras)
            string idProdutoString = row.Cells["IdProduto"].Value.ToString();

            // Validação e Busca
            // Tenta converter a string do código de barras para long (EAN-13)
            if (!long.TryParse(idProdutoString, out long idProdutoLong))
            {
                MessageBox.Show("Erro: O ID do produto selecionado não é um número válido (EAN-13).", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Busca o objeto Produto completo no banco
            ProdutoSelecionado = controller.GetById(idProdutoLong);

            // Define o resultado como OK e fecha a janela
            this.DialogResult = DialogResult.OK; // Indica sucesso na seleção
            this.Close();
        }
    }
}