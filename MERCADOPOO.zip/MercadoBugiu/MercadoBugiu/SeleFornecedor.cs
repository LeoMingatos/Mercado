﻿using MERCADOPOO.Controller;
using MERCADOPOO.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MERCADOPOO
{
    // Formulário para pesquisar e selecionar um único fornecedor 
    public partial class SeleFornecedor : Form
    {
        // Controller para acesso aos dados do fornecedor
        private readonly FornecedorController controller = new FornecedorController();

        // Propriedade para armazenar o objeto Fornecedor selecionado para retorno.
        public Fornecedor FornecedorSelecionado { get; private set; }

        public SeleFornecedor()
        {
            InitializeComponent();
            CarregarTodosFornecedores();
            // Configura a DGV para selecionar a linha inteira ao clicar
            dgvResultados.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvResultados.MultiSelect = false;
        }

        // Carrega a lista completa de fornecedores ao iniciar a tela.
        private void CarregarTodosFornecedores()
        {
              dgvResultados.DataSource = controller.GetAll();
        }

        // --- LÓGICA DE PESQUISA E SELEÇÃO ---

        // Lógica principal que pega o fornecedor selecionado e define o retorno.
        private void SelecionarFornecedor()
        {
            // Verifica se há uma linha selecionada
            if (dgvResultados.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecione um fornecedor na lista antes de continuar.", "Atenção");
                return;
            }

            // Pega a linha selecionada
            DataGridViewRow row = dgvResultados.SelectedRows[0];
            string idFornecedorString = row.Cells["IdFornecedor"].Value.ToString();

            // Validação e Busca
            if (!int.TryParse(idFornecedorString, out int idFornecedor))
            {
                MessageBox.Show("Erro interno: ID do fornecedor inválido.", "Erro de Dados", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Busca o objeto Fornecedor completo
            FornecedorSelecionado = controller.GetById(idFornecedor);

            // Define o resultado como OK e fecha a janela
            this.DialogResult = DialogResult.OK; // Indica sucesso na seleção
            this.Close();
        }

        // Disparado ao sair do campo de busca ou clicar no botão Buscar.
        private void btnBuscar_Click(object sender, EventArgs e)
        {
           
            string nomeBusca = txtPesquisaNome.Text.Trim();

            if (string.IsNullOrWhiteSpace(nomeBusca))
            {
                CarregarTodosFornecedores(); // Recarrega tudo se o campo estiver vazio
                return;
            }

            // Chamando o método que busca por Razão Social (que retorna a lista filtrada)
            dgvResultados.DataSource = controller.GetByRazaoSocial(nomeBusca);

            if (dgvResultados.Rows.Count == 0)
            {
                MessageBox.Show($"Nenhum fornecedor encontrado com o nome/razão '{nomeBusca}'.", "Busca Vazia");
            }
        }

        //  Duplo clique na linha (para agilizar a seleção)
        private void dgvResultados_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                SelecionarFornecedor();
            }
        }

        // Clique no botão Selecionar
        private void btnSelecionar_Click_1(object sender, EventArgs e)
        {
            SelecionarFornecedor();
        }
    }
}