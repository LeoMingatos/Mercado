﻿using MERCADOPOO.Controller;
using MERCADOPOO.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace MERCADOPOO
{
    // Formulário para pesquisar e selecionar um único usuário
    public partial class SeleUsuario : Form
    {
        // Controller para acesso aos dados do usuário
        private readonly UsuarioController controller = new UsuarioController();

        // Propriedade para armazenar o objeto Usuario selecionado para retorno.
        public Usuario UsuarioSelecionado { get; private set; }

        public SeleUsuario()
        {
            InitializeComponent();
            CarregarTodosUsuarios(); // Carrega a lista de usuários ao iniciar
            // Configura a DGV para selecionar a linha inteira ao clicar
            dgvResultados.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvResultados.MultiSelect = false; // Permite apenas uma seleção
        }

        // Carrega a lista completa de usuários na DataGridView.
        private void CarregarTodosUsuarios()
        {
            dgvResultados.DataSource = controller.GetAll();
        }

        // --- LÓGICA DE BUSCA E SELEÇÃO ---

        // Botão Buscar
        // //Pesquisa por Nome.
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string nomeBusca = txtUsuario.Text.Trim();

            if (string.IsNullOrWhiteSpace(nomeBusca))
            {
                CarregarTodosUsuarios(); // Se vazio, recarrega tudo
                return;
            }

            // Chama o método do Controller para buscar por nome
            dgvResultados.DataSource = controller.GetByNome(nomeBusca);

            if (dgvResultados.Rows.Count == 0)
            {
                MessageBox.Show($"Nenhum usuário encontrado com o nome '{nomeBusca}'.", "Busca Vazia");
            }
        }

        // Lógica principal que pega o usuário selecionado e define o retorno.
        private void SelecionarUsuario()
        {
            // Verifica se há uma linha selecionada
            if (dgvResultados.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecione um usuário na lista antes de continuar.");
                return;
            }

            // Pega a linha selecionada
            DataGridViewRow row = dgvResultados.SelectedRows[0];

            // Pega o ID do usuário da célula
            string idUsuarioString = row.Cells["IdUsuario"].Value.ToString();

            // Validação e Mapeamento
            if (!int.TryParse(idUsuarioString, out int idUsuario))
            {
                MessageBox.Show("Erro: O ID do usuário selecionado não é um número válido.", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Mapeia os dados da linha selecionada para o objeto Usuario
            UsuarioSelecionado = new Usuario
            {
                IdUsuario = Convert.ToInt32(row.Cells["IdUsuario"].Value),
                Nome = row.Cells["Nome"].Value.ToString(),
                Login = row.Cells["Login"].Value.ToString(),
                Senha = row.Cells["Senha"].Value.ToString(),
                NivelAcesso = row.Cells["NivelAcesso"].Value.ToString()
            };

            // Define o resultado como OK e fecha a janela
            this.DialogResult = DialogResult.OK; // Indica sucesso na seleção
            this.Close();
        }

        // Clique no botão Selecionar 
        private void btnSelecionar_Click(object sender, EventArgs e)
        {
            SelecionarUsuario();
        }

        // Clique no Conteúdo da Célula 
        private void dgvResultados_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
            }
        }

  
    }
}