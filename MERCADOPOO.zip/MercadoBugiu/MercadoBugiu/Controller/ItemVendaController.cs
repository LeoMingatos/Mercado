﻿using MERCADOPOO.Model;
using MERCADOPOO.Services; 
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace MERCADOPOO.Controller
{
    public class ItemVendaController
    {
       
        private readonly DataBaseServerSQL dataBase = new DataBaseServerSQL();

        // CREATE (Insere um item de venda e retorna o ID gerado)
        public int Inserir(ItemVenda item)
        {
            string sql = @"
                INSERT INTO ItemVenda (IdVenda, IdProduto, Quantidade, Subtotal) 
                VALUES (@IdVenda, @IdProduto, @Quantidade, @Subtotal);
                SELECT SCOPE_IDENTITY();"; // Retorna o ID gerado

            SqlCommand command = new SqlCommand(sql);

           
            command.Parameters.AddWithValue("@IdVenda", item.IdVenda);
            command.Parameters.AddWithValue("@IdProduto", item.IdProduto);
            command.Parameters.AddWithValue("@Quantidade", item.Quantidade);
            command.Parameters.AddWithValue("@Subtotal", item.Subtotal);

            // ExecuteScalar executa retorna o valor (o novo IdItemVenda)
            object result = dataBase.ExecuteScalar(command);

            // Verifica se o resultado não é nulo antes de converter
            if (result != null && result != DBNull.Value)
            {
                return Convert.ToInt32(result);
            }
            return 0; // Retorna 0 em caso de falha
        }

        // READ (Busca todos os itens de uma venda específica)
        public List<ItemVenda> GetItensByVenda(int idVenda)
        {
            List<ItemVenda> listaItens = new List<ItemVenda>();

            // Query com JOIN para obter Nome e Preço (para cálculo/exibição)
            string sql = @"
                SELECT IV.*, P.Nome as NomeProduto, P.Preco as PrecoUnitario
                FROM ItemVenda IV
                JOIN Produto P ON IV.IdProduto = P.IdProduto
                WHERE IV.IdVenda = @IdVenda
                ORDER BY P.Nome";

            SqlCommand command = new SqlCommand(sql);
            command.Parameters.AddWithValue("@IdVenda", idVenda);

            DataTable dt = dataBase.GetDataTable(command);

            // Mapeamento dos resultados para a lista de objetos ItemVenda
            foreach (DataRow row in dt.Rows)
            {
                // Mapeia os campos da tabela ItemVenda (IV)
                ItemVenda item = new ItemVenda
                {
                    IdItem = Convert.ToInt32(row["IdItem"]), 
                    IdVenda = Convert.ToInt32(row["IdVenda"]),
                    IdProduto = row["IdProduto"].ToString(),
                    Quantidade = Convert.ToInt32(row["Quantidade"]),
                    Subtotal = Convert.ToDecimal(row["Subtotal"]),

                    // Mapeia campos auxiliares obtidos via JOIN 
                    NomeProduto = row["NomeProduto"].ToString(),
                    PrecoUnitario = Convert.ToDecimal(row["PrecoUnitario"])
                };
                listaItens.Add(item);
            }

            return listaItens;
        }

        // DELETE (Exclui todos os itens vinculados a um ID de Venda)
        public int ExcluirItensPorVenda(int idVenda)
        {
            string sql = "DELETE FROM ItemVenda WHERE IdVenda = @IdVenda";

            SqlCommand command = new SqlCommand(sql);
            command.Parameters.AddWithValue("@IdVenda", idVenda);

            // ExecuteSQL é usado para comandos que não retornam dados (retorna linhas afetadas)
            return dataBase.ExecuteSQL(command);
        }
    }
}