﻿using MERCADOPOO.Model;
using MERCADOPOO.Services;
using System;
using System.Collections.Generic;
using System.Data; 
using System.Data.SqlClient; 
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class ClienteController
{
    // Acesso ao banco. Variável usada para executar comandos SQL.
    DataBaseServerSQL dataBase = new DataBaseServerSQL();

    // --- MÉTODOS CRUD (CREATE, READ, UPDATE, DELETE) ---

    // CREATE (Inserir novo cliente)
    public int Inserir(Cliente cliente)
    {
        string query =
            "INSERT INTO Cliente (Nome, CPF, Telefone, Email) " +
            "VALUES (@Nome, @CPF, @Telefone, @Email)";

        SqlCommand command = new SqlCommand(query);
        command.Parameters.AddWithValue("@Nome", cliente.Nome);
        command.Parameters.AddWithValue("@CPF", cliente.CPF);
        command.Parameters.AddWithValue("@Telefone", cliente.Telefone);
        command.Parameters.AddWithValue("@Email", cliente.Email);

        // Executa o comando SQL (ExecuteSQL retorna o número de linhas afetadas/ID)
        return dataBase.ExecuteSQL(command);
    }

    // UPDATE (Alterar cliente existente)
    public int Alterar(Cliente cliente)
    {
        string query =
            "UPDATE Cliente SET " +
            "Nome = @Nome, " +
            "CPF = @CPF, " +
            "Telefone = @Telefone, " +
            "Email = @Email " +
            "WHERE IdCliente = @IdCliente"; // Identifica qual cliente será alterado

        SqlCommand command = new SqlCommand(query);
        command.Parameters.AddWithValue("@Nome", cliente.Nome);
        command.Parameters.AddWithValue("@CPF", cliente.CPF);
        command.Parameters.AddWithValue("@Telefone", cliente.Telefone);
        command.Parameters.AddWithValue("@Email", cliente.Email);
        command.Parameters.AddWithValue("@IdCliente", cliente.IdCliente);

        return dataBase.ExecuteSQL(command);
    }

    // DELETE (Excluir cliente pelo ID)
    public int Excluir(int idCliente)
    {
        string query =
            "DELETE FROM Cliente WHERE IdCliente = @IdCliente";

        SqlCommand command = new SqlCommand(query);
        command.Parameters.AddWithValue("@IdCliente", idCliente);

        return dataBase.ExecuteSQL(command);
    }

    // SELECT por ID
    // Retorna um único objeto Cliente ou null se não for encontrado.
    public Cliente GetById(int idCliente)
    {
        string query =
            "SELECT * FROM Cliente WHERE IdCliente = @IdCliente";

        SqlCommand command = new SqlCommand(query);
        command.Parameters.AddWithValue("@IdCliente", idCliente);

        DataTable dataTable = dataBase.GetDataTable(command);

        if (dataTable.Rows.Count > 0)
        {
            DataRow row = dataTable.Rows[0]; // Pega a primeira linha encontrada

            Cliente cliente = new Cliente();
            // Mapeamento dos campos do banco para o objeto Cliente
            cliente.IdCliente = Convert.ToInt32(row["IdCliente"]);
            cliente.Nome = row["Nome"].ToString();
            cliente.CPF = row["CPF"].ToString();
            cliente.Telefone = row["Telefone"].ToString();
            cliente.Email = row["Email"].ToString();

            return cliente;
        }

        return null; // Retorna nulo se o ID não for encontrado
    }

    // --- MÉTODOS DE PESQUISA FLEXÍVEL ---

    // Função interna principal para buscar clientes com base em qualquer filtro.
    private List<Cliente> GetByFilter(string filtro = "")
    {
        string query = "SELECT * FROM Cliente ";

        // Adiciona a cláusula WHERE se um filtro for fornecido (ex: "Nome LIKE 'Maria%'")
        if (!string.IsNullOrEmpty(filtro))
            query += "WHERE " + filtro + " ";

        query += "ORDER BY Nome";

        SqlCommand command = new SqlCommand(query);
        DataTable dataTable = dataBase.GetDataTable(command);

        List<Cliente> clientes = new List<Cliente>();

        // Loop para mapear cada linha do resultado para um objeto Cliente
        foreach (DataRow row in dataTable.Rows)
        {
            Cliente cliente = new Cliente();
            cliente.IdCliente = Convert.ToInt32(row["IdCliente"]);
            cliente.Nome = row["Nome"].ToString();
            cliente.CPF = row["CPF"].ToString();
            cliente.Telefone = row["Telefone"].ToString();
            cliente.Email = row["Email"].ToString();

            clientes.Add(cliente);
        }

        return clientes;
    }

    // SELECT todos (sem filtr)
    public List<Cliente> GetAll()
    {
        return GetByFilter();
    }

    // SELECT por nome (formatando a cláusula LIKE)
    public List<Cliente> GetByName(string value)
    {
        // Ex: WHERE Nome LIKE '%[valor]%'
        return GetByFilter("Nome LIKE '%" + value + "%'");
    }

    // SELECT por CPF (com busca exata)
    public List<Cliente> GetByCPF(string value)
    {
        // Ex: WHERE CPF = '[valor]'
        return GetByFilter("CPF = '" + value + "'");
    }
}