﻿using MERCADOPOO.Model;
using MERCADOPOO.Services;
using System;
using System.Collections.Generic;
using System.Data; 
using System.Data.SqlClient; 
using System.Linq;

namespace MERCADOPOO.Controller
{
    public class VendaController
    {
      
        private DataBaseServerSQL dataBase = new DataBaseServerSQL();

        // --- MÉTODOS CRUD PADRÃO ---

        // INSERT - Insere uma nova venda e retorna o ID gerado 
        public int Inserir(Venda venda)
        {
            string query = @"INSERT INTO Venda (DataVenda, IdCliente, IdUsuario, ValorTotal)
                             VALUES (@DataVenda, @IdCliente, @IdUsuario, @ValorTotal);
                             SELECT SCOPE_IDENTITY();"; // Retorna o último ID inserido

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@DataVenda", venda.DataVenda);
            command.Parameters.AddWithValue("@IdCliente", venda.IdCliente);
            command.Parameters.AddWithValue("@IdUsuario", venda.IdUsuario);
            command.Parameters.AddWithValue("@ValorTotal", venda.ValorTotal);

            object result = dataBase.ExecuteScalar(command); // Executa e retorna o ID
            return Convert.ToInt32(result);
        }

        // UPDATE - Altera os dados do cabeçalho de uma venda existente.
        public int Alterar(Venda venda)
        {
            string query = @"UPDATE Venda
                             SET DataVenda = @DataVenda,
                                 IdCliente = @IdCliente,
                                 IdUsuario = @IdUsuario,
                                 ValorTotal = @ValorTotal
                             WHERE IdVenda = @IdVenda";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@DataVenda", venda.DataVenda);
            command.Parameters.AddWithValue("@IdCliente", venda.IdCliente);
            command.Parameters.AddWithValue("@IdUsuario", venda.IdUsuario);
            command.Parameters.AddWithValue("@ValorTotal", venda.ValorTotal);
            command.Parameters.AddWithValue("@IdVenda", venda.IdVenda);

            return dataBase.ExecuteSQL(command);
        }

        // DELETE - Exclui uma venda pelo ID (o que geralmente requer exclusão dos itens de venda primeiro).
        public int Excluir(int idVenda)
        {
            string query = "DELETE FROM Venda WHERE IdVenda = @IdVenda";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdVenda", idVenda);

            return dataBase.ExecuteSQL(command);
        }

        // --- MÉTODOS DE CONSULTA BÁSICA ---

        // SELECT todos - Retorna todas as vendas como uma lista de objetos Venda.
        public List<Venda> GetAll()
        {
            string query = "SELECT * FROM Venda ORDER BY DataVenda DESC";
            SqlCommand command = new SqlCommand(query);
            DataTable dt = dataBase.GetDataTable(command);

            List<Venda> vendas = new List<Venda>();
            foreach (DataRow row in dt.Rows)
            {
                vendas.Add(new Venda
                {
                    IdVenda = Convert.ToInt32(row["IdVenda"]),
                    DataVenda = Convert.ToDateTime(row["DataVenda"]),
                    IdCliente = Convert.ToInt32(row["IdCliente"]),
                    IdUsuario = Convert.ToInt32(row["IdUsuario"]),
                    ValorTotal = Convert.ToDecimal(row["ValorTotal"])
                });
            }

            return vendas;
        }

        // SELECT por ID - Retorna um único objeto Venda ou null.
        public Venda GetById(int idVenda)
        {
            string query = "SELECT * FROM Venda WHERE IdVenda = @IdVenda";
            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdVenda", idVenda);
            DataTable dt = dataBase.GetDataTable(command);

            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                return new Venda
                {
                    IdVenda = Convert.ToInt32(row["IdVenda"]),
                    DataVenda = Convert.ToDateTime(row["DataVenda"]),
                    IdCliente = Convert.ToInt32(row["IdCliente"]),
                    IdUsuario = Convert.ToInt32(row["IdUsuario"]),
                    ValorTotal = Convert.ToDecimal(row["ValorTotal"])
                };
            }

            return null;
        }

        // SELECT por Cliente - Retorna todas as vendas de um cliente específico.
        public List<Venda> GetByCliente(int idCliente)
        {
            string query = "SELECT * FROM Venda WHERE IdCliente = @IdCliente";
            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdCliente", idCliente);
            DataTable dt = dataBase.GetDataTable(command);

            List<Venda> vendas = new List<Venda>();
            foreach (DataRow row in dt.Rows)
            {
                vendas.Add(new Venda
                {
                    IdVenda = Convert.ToInt32(row["IdVenda"]),
                    DataVenda = Convert.ToDateTime(row["DataVenda"]),
                    IdCliente = Convert.ToInt32(row["IdCliente"]),
                    IdUsuario = Convert.ToInt32(row["IdUsuario"]),
                    ValorTotal = Convert.ToDecimal(row["ValorTotal"])
                });
            }

            return vendas;
        }

        // SELECT por Período - Retorna vendas dentro de um intervalo de datas com nomes de Cliente/Usuário.
        public DataTable GetVendasPorPeriodo(DateTime dataInicio, DateTime dataFim)
        {
            // Esta query faz o JOIN para exibir os Nomes nas grids
            string query = @"
                SELECT V.IdVenda, V.DataVenda, V.ValorTotal,
                       C.Nome AS NomeCliente, U.Nome AS NomeUsuario
                FROM Venda V
                JOIN Cliente C ON V.IdCliente = C.IdCliente
                JOIN Usuario U ON V.IdUsuario = U.IdUsuario
                WHERE V.DataVenda >= @DataInicio AND V.DataVenda <= @DataFim
                ORDER BY V.DataVenda DESC";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@DataInicio", dataInicio.Date);
            command.Parameters.AddWithValue("@DataFim", dataFim.Date.AddDays(1)); // Inclui o dia final

            return dataBase.GetDataTable(command);
        }


        
        // MÉTODO AVANÇADO: FILTRO PARA HISTÓRICO DE VENDAS
      
      
        // Busca histórico de vendas filtrado por data, produto e fornecedor.
        // Retorna uns cabeçalhos de venda e nomes (Cliente/Usuário).
        
        public DataTable GetVendasFiltradas(DateTime dataInicio, DateTime dataFim, long? idProduto, int? idFornecedor)
        {
            // Constrói a Query Base com JOINs necessários para FILTRAR
            string query = @"
                SELECT 
                    V.IdVenda, V.DataVenda, V.ValorTotal,
                    C.Nome AS NomeCliente, 
                    U.Nome AS NomeUsuario
                FROM Venda V
                JOIN Cliente C ON V.IdCliente = C.IdCliente
                JOIN Usuario U ON V.IdUsuario = U.IdUsuario
                
                -- JOINs necessários para acesso aos filtros de Produto e Fornecedor
                JOIN ItemVenda IV ON V.IdVenda = IV.IdVenda 
                JOIN Produto P ON IV.IdProduto = P.IdProduto
                
                WHERE V.DataVenda >= @DataInicio AND V.DataVenda <= @DataFim";

            // Constrói a cláusula WHERE dinamicamente 
            if (idProduto.HasValue && idProduto.Value > 0)
            {
                query += " AND IV.IdProduto = @IdProduto";
            }
            if (idFornecedor.HasValue && idFornecedor.Value > 0)
            {
                query += " AND P.IdFornecedor = @IdFornecedor";
            }

            // Agrupamento é crucial para que cada venda apareça apenas uma vez na lista
            query += " GROUP BY V.IdVenda, V.DataVenda, V.ValorTotal, C.Nome, U.Nome ORDER BY V.DataVenda DESC";

            SqlCommand command = new SqlCommand(query);

            // Adiciona Parâmetros
            command.Parameters.AddWithValue("@DataInicio", dataInicio.Date);
            command.Parameters.AddWithValue("@DataFim", dataFim.Date.AddDays(1));

            if (idProduto.HasValue && idProduto.Value > 0)
            {
                command.Parameters.AddWithValue("@IdProduto", idProduto.Value);
            }
            if (idFornecedor.HasValue && idFornecedor.Value > 0)
            {
                command.Parameters.AddWithValue("@IdFornecedor", idFornecedor.Value);
            }

            // Executa e Retorna o DataTable para a DGV
            return dataBase.GetDataTable(command);
        }
    }
} 