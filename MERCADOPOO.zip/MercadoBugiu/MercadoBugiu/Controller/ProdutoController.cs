﻿using MERCADOPOO.Model;
using MERCADOPOO.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MERCADOPOO.Controller
{
   
    public class ProdutoController
    {
       
        private readonly DataBaseServerSQL dataBase = new DataBaseServerSQL();

        // --- MÉTODOS CRUD PADRÃO ---

        // INSERT (Cria um novo produto)
        public int Inserir(Produto produto)
        {
            string query = @"INSERT INTO Produto (IdProduto, Nome, Preco, Estoque, IdFornecedor)
                             VALUES (@IdProduto, @Nome, @Preco, @Estoque, @IdFornecedor)";

            SqlCommand command = new SqlCommand(query);
         
            command.Parameters.AddWithValue("@IdProduto", produto.IdProduto);
            command.Parameters.AddWithValue("@Nome", produto.Nome);
            command.Parameters.AddWithValue("@Preco", produto.Preco);
            command.Parameters.AddWithValue("@Estoque", produto.Estoque);
            command.Parameters.AddWithValue("@IdFornecedor", produto.IdFornecedor);

            return dataBase.ExecuteSQL(command);
        }

        // UPDATE (Atualiza um produto existente)
        public int Alterar(Produto produto)
        {
            string query = @"UPDATE Produto
                             SET Nome = @Nome,
                                 Preco = @Preco,
                                 Estoque = @Estoque,
                                 IdFornecedor = @IdFornecedor
                             WHERE IdProduto = @IdProduto";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@Nome", produto.Nome);
            command.Parameters.AddWithValue("@Preco", produto.Preco);
            command.Parameters.AddWithValue("@Estoque", produto.Estoque);
            command.Parameters.AddWithValue("@IdFornecedor", produto.IdFornecedor);
            command.Parameters.AddWithValue("@IdProduto", produto.IdProduto);

            return dataBase.ExecuteSQL(command);
        }

        // DELETE (Exclui um produto pelo ID)
        public int Excluir(long idProduto)
        {
            string query = "DELETE FROM Produto WHERE IdProduto = @IdProduto";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdProduto", idProduto);

            return dataBase.ExecuteSQL(command);
        }

        // SELECT por ID
        // Retorna um objeto Produto único ou null.
        public Produto GetById(long idProduto)
        {
            string query = "SELECT * FROM Produto WHERE IdProduto = @IdProduto";
            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdProduto", idProduto);

            DataTable table = dataBase.GetDataTable(command);
            if (table.Rows.Count == 0)
                return null;

            DataRow row = table.Rows[0];
            // Mapeamento dos campos do DataRow para o objeto Produto
            return new Produto
            {
                IdProduto = Convert.ToInt64(row["IdProduto"]),
                Nome = row["Nome"].ToString(),
                Preco = Convert.ToDecimal(row["Preco"]),
                Estoque = Convert.ToInt32(row["Estoque"]),
                IdFornecedor = Convert.ToInt32(row["IdFornecedor"])
            };
        }

        // SELECT todos
        // Retorna todos os produtos como uma lista.
        public List<Produto> GetAll()
        {
            string query = "SELECT * FROM Produto ORDER BY Nome";
            SqlCommand command = new SqlCommand(query);

            DataTable table = dataBase.GetDataTable(command);
            List<Produto> produtos = new List<Produto>();

            foreach (DataRow row in table.Rows)
            {
                produtos.Add(new Produto
                {
                    IdProduto = Convert.ToInt64(row["IdProduto"]),
                    Nome = row["Nome"].ToString(),
                    Preco = Convert.ToDecimal(row["Preco"]),
                    Estoque = Convert.ToInt32(row["Estoque"]),
                    IdFornecedor = Convert.ToInt32(row["IdFornecedor"])
                });
            }

            return produtos;
        }

        
        // CONSULTA AVANÇADA DE ESTOQUE/PRODUTOS
        
      
        // Retorna o estoque atual e o Fornecedor, filtrado por Nome, Marca ou ID do Produto.
        // Usado na tela de ConsultaEstoque e na PesquisaProduto.
        
        public DataTable GetEstoqueComFiltro(string termoBusca)
        {
            string idTermo = termoBusca.Trim();
            // Verifica se o termo de busca é um ID numérico (EAN-13)
            bool isId = long.TryParse(idTermo, out long idBusca);

            // 1. QUERY BASE: Faz JOIN com Fornecedor para obter a Razão Social (Marca)
            string query = @"
                SELECT 
                    P.IdProduto, P.Nome, P.Estoque, P.Preco, 
                    F.RazaoSocial AS Fornecedor
                FROM Produto P
                INNER JOIN Fornecedor F ON P.IdFornecedor = F.IdFornecedor
                WHERE (P.Nome LIKE @Termo OR F.RazaoSocial LIKE @Termo)"; // Filtro por Nome OU Marca

            // 2. Adiciona a condição de ID se o termo for numérico
            if (isId)
            {
                // Inclui a busca exata por ID do produto
                query += " OR P.IdProduto = @IdBusca";
            }

            query += " ORDER BY P.Nome";

            SqlCommand command = new SqlCommand(query);

            // 3. Parâmetros: @Termo é usado para a busca LIKE (Nome/Marca)
            command.Parameters.AddWithValue("@Termo", "%" + termoBusca + "%");

            // @IdBusca só é adicionado se o termo for numérico
            if (isId)
            {
                command.Parameters.AddWithValue("@IdBusca", idBusca);
            }

            return dataBase.GetDataTable(command); // Retorna o resultado como DataTable
        }

        // MÉTODO DE ESTOQUE (ReduzirEstoque)

        public void ReduzirEstoque(long idProduto, int quantidadeVendida)
        {
            string query = @"
                UPDATE Produto 
                SET Estoque = Estoque - @QuantidadeVendida 
                WHERE IdProduto = @IdProduto";

            SqlCommand command = new SqlCommand(query);

            command.Parameters.AddWithValue("@QuantidadeVendida", quantidadeVendida);
            command.Parameters.AddWithValue("@IdProduto", idProduto);

            int linhasAfetadas = dataBase.ExecuteSQL(command);

            if (linhasAfetadas == 0)
            {
                // Lança exceção se não conseguir atualizar o estoque (erro crítico)
                throw new Exception($"Falha crítica: Nenhuma linha afetada ao reduzir estoque do produto ID {idProduto}. Produto pode não existir.");
            }
        }
    }
}