﻿using MERCADOPOO.Model;
using MERCADOPOO.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MERCADOPOO.Controller
{
    public class UsuarioController
    {
       
        private readonly DataBaseServerSQL db = new DataBaseServerSQL();

        // Método auxiliar para mapear um DataRow para um objeto Usuario.
        private Usuario MapearUsuario(DataRow row)
        {
            return new Usuario
            {
                IdUsuario = Convert.ToInt32(row["IdUsuario"]),
                Nome = row["Nome"].ToString(),
                Login = row["Login"].ToString(),
                Senha = row["Senha"].ToString(),
                NivelAcesso = row["NivelAcesso"].ToString()
            };
        }

        // --- MÉTODOS CRUD (CREATE, READ, UPDATE, DELETE) ---

        // CREATE - Inserir novo usuário no banco.
        public int Inserir(Usuario usuario)
        {
            string query = @"
                INSERT INTO Usuario (Nome, Login, Senha, NivelAcesso)
                VALUES (@Nome, @Login, @Senha, @NivelAcesso)";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@Nome", usuario.Nome);
            command.Parameters.AddWithValue("@Login", usuario.Login);
            command.Parameters.AddWithValue("@Senha", usuario.Senha);
            command.Parameters.AddWithValue("@NivelAcesso", usuario.NivelAcesso);

            return db.ExecuteSQL(command); // Executa o INSERT
        }

        // UPDATE - Alterar usuário existente.
        public int Alterar(Usuario usuario)
        {
            string query = @"
                UPDATE Usuario SET 
                    Nome = @Nome,
                    Login = @Login,
                    Senha = @Senha,
                    NivelAcesso = @NivelAcesso
                WHERE IdUsuario = @IdUsuario"; // Identifica o registro pelo ID

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdUsuario", usuario.IdUsuario);
            command.Parameters.AddWithValue("@Nome", usuario.Nome);
            command.Parameters.AddWithValue("@Login", usuario.Login);
            command.Parameters.AddWithValue("@Senha", usuario.Senha);
            command.Parameters.AddWithValue("@NivelAcesso", usuario.NivelAcesso);

            return db.ExecuteSQL(command); // Executa o UPDATE
        }

        // DELETE - Excluir usuário pelo ID.
        public int Excluir(int idUsuario)
        {
            string query = "DELETE FROM Usuario WHERE IdUsuario = @IdUsuario";
            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdUsuario", idUsuario);

            return db.ExecuteSQL(command); // Executa o DELETE
        }

        // READ - Buscar todos os usuários
        public DataTable GetAll()
        {
            string query = "SELECT * FROM Usuario ORDER BY Nome";
            SqlCommand command = new SqlCommand(query);
            return db.GetDataTable(command); // Retorna a tabela completa
        }

        // READ - Buscar por nome 
        public DataTable GetByNome(string nome)
        {
            string query = "SELECT * FROM Usuario WHERE Nome LIKE @Nome ORDER BY Nome";
            SqlCommand command = new SqlCommand(query);
            // Usa LIKE para busca parcial (Ex: 'A%' ou '%B%')
            command.Parameters.AddWithValue("@Nome", "%" + nome + "%");
            return db.GetDataTable(command);
        }

        // READ - Buscar por ID
        // Usado para carregar um único usuário na DGV.
        public DataTable GetById(int idUsuario)
        {
            string query = "SELECT * FROM Usuario WHERE IdUsuario = @IdUsuario";
            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdUsuario", idUsuario);

            return db.GetDataTable(command);
        }

        // --- MÉTODOS DE AUTENTICAÇÃO ---

        // READ - Validar Login e Senha (Retorna objeto ÚNICO ou null).
        public Usuario ValidarLogin(string login, string senha)
        {
            string query = "SELECT * FROM Usuario WHERE Login = @Login AND Senha = @Senha";
            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@Login", login);
            command.Parameters.AddWithValue("@Senha", senha);

            DataTable table = db.GetDataTable(command);

            if (table.Rows.Count == 0)
                return null; // Credenciais inválidas

            DataRow row = table.Rows[0];

            return MapearUsuario(row); // Mapeia o usuário encontrado
        }
    }
}