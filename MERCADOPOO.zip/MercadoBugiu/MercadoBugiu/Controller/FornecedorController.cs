﻿using MERCADOPOO.Model;
using MERCADOPOO.Services;
using System;
using System.Collections.Generic;
using System.Data; 
using System.Data.SqlClient; 
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MERCADOPOO.Controller
{
    
    public class FornecedorController
    {
        // Acesso ao banco.
        DataBaseServerSQL dataBase = new DataBaseServerSQL();

        // --- MÉTODOS CRUD (CREATE, READ, UPDATE, DELETE) ---

        // CREATE (Inserir novo fornecedor)
        public int Inserir(Fornecedor fornecedor)
        {
            string query = @"INSERT INTO Fornecedor (RazaoSocial, CNPJ, Telefone, Email)
                             VALUES (@RazaoSocial, @CNPJ, @Telefone, @Email)";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@RazaoSocial", fornecedor.RazaoSocial);
            command.Parameters.AddWithValue("@CNPJ", fornecedor.CNPJ);
            command.Parameters.AddWithValue("@Telefone", fornecedor.Telefone);
            command.Parameters.AddWithValue("@Email", fornecedor.Email);

            return dataBase.ExecuteSQL(command); // Executa o INSERT
        }

        // UPDATE (Alterar fornecedor existente)
        public int Alterar(Fornecedor fornecedor)
        {
            string query = @"UPDATE Fornecedor
                             SET RazaoSocial = @RazaoSocial,
                                 CNPJ = @CNPJ,
                                 Telefone = @Telefone,
                                 Email = @Email
                             WHERE IdFornecedor = @IdFornecedor"; // Identifica o registro pelo ID

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@RazaoSocial", fornecedor.RazaoSocial);
            command.Parameters.AddWithValue("@CNPJ", fornecedor.CNPJ);
            command.Parameters.AddWithValue("@Telefone", fornecedor.Telefone);
            command.Parameters.AddWithValue("@Email", fornecedor.Email);
            command.Parameters.AddWithValue("@IdFornecedor", fornecedor.IdFornecedor);

            return dataBase.ExecuteSQL(command); // Executa o UPDATE
        }

        // DELETE (Excluir fornecedor pelo ID)
        public int Excluir(int idFornecedor)
        {
            string query = "DELETE FROM Fornecedor WHERE IdFornecedor = @IdFornecedor";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdFornecedor", idFornecedor);

            return dataBase.ExecuteSQL(command); // Executa o DELETE
        }

        // SELECT por ID
        // Retorna um único objeto Fornecedor ou null.
        public Fornecedor GetById(int idFornecedor)
        {
            string query = "SELECT * FROM Fornecedor WHERE IdFornecedor = @IdFornecedor";

            SqlCommand command = new SqlCommand(query);
            command.Parameters.AddWithValue("@IdFornecedor", idFornecedor);

            DataTable dataTable = dataBase.GetDataTable(command);

            if (dataTable.Rows.Count > 0)
            {
                DataRow row = dataTable.Rows[0]; // Pega a primeira linha

                Fornecedor fornecedor = new Fornecedor
                {
                    // Mapeamento dos campos do banco para o objeto Fornecedor
                    IdFornecedor = Convert.ToInt32(row["IdFornecedor"]),
                    RazaoSocial = row["RazaoSocial"].ToString(),
                    CNPJ = row["CNPJ"].ToString(),
                    Telefone = row["Telefone"].ToString(),
                    Email = row["Email"].ToString()
                };

                return fornecedor; // Retorna o objeto encontrado
            }

            return null; // Retorna nulo se o ID não for encontrado
        }

        // --- MÉTODOS DE PESQUISA FLEXÍVEL ---

        // Função interna principal para buscar fornecedores com base em qualquer filtro.
        // O parâmetro 'filtro' deve ser uma string SQL (ex: "RazaoSocial LIKE '%VALOR%'").
        public List<Fornecedor> GetByFilter(string filtro = "")
        {
            string query = "SELECT * FROM Fornecedor ";

            if (!string.IsNullOrEmpty(filtro))
                query += "WHERE " + filtro + " "; // Adiciona a cláusula WHERE

            query += "ORDER BY RazaoSocial";

            SqlCommand command = new SqlCommand(query);
            DataTable dataTable = dataBase.GetDataTable(command);

            List<Fornecedor> fornecedores = new List<Fornecedor>();

            // Loop para mapear cada linha do resultado para um objeto Fornecedor
            foreach (DataRow row in dataTable.Rows)
            {
                Fornecedor fornecedor = new Fornecedor
                {
                    IdFornecedor = Convert.ToInt32(row["IdFornecedor"]),
                    RazaoSocial = row["RazaoSocial"].ToString(),
                    CNPJ = row["CNPJ"].ToString(),
                    Telefone = row["Telefone"].ToString(),
                    Email = row["Email"].ToString()
                };
                fornecedores.Add(fornecedor);
            }

            return fornecedores; // Retorna a lista de fornecedores
        }

        // SELECT todos (sem filtro)
        public List<Fornecedor> GetAll()
        {
            return GetByFilter();
        }

        // SELECT por Razão Social (Busca parcial usando LIKE)
        public List<Fornecedor> GetByRazaoSocial(string value)
        {
            // Formata a string SQL para busca LIKE (Ex: WHERE RazaoSocial LIKE '%Busca%')
            return GetByFilter("RazaoSocial LIKE '%" + value + "%'");
        }

        // SELECT por CNPJ (Busca exata)
        public List<Fornecedor> GetByCNPJ(string value)
        {
            // Formata a string SQL para busca exata (Ex: WHERE CNPJ = '11.222.333/0001-44')
            return GetByFilter("CNPJ = '" + value + "'");
        }
    }
}