﻿using System.Drawing;
using System.Windows.Forms;

namespace MERCADOPOO
{
    partial class TelaLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtSenha = new TextBox();
            label2 = new Label();
            btnEntrar = new Button();
            label3 = new Label();
            label1 = new Label();
            txtLogin = new TextBox();
            pnlContainer = new Panel();
            pnlContainer.SuspendLayout();
            SuspendLayout();
            // 
            // txtSenha
            // 
            txtSenha.Anchor = AnchorStyles.None;
            txtSenha.BorderStyle = BorderStyle.FixedSingle;
            txtSenha.Cursor = Cursors.Hand;
            txtSenha.Location = new Point(42, 192);
            txtSenha.Name = "txtSenha";
            txtSenha.PasswordChar = '*';
            txtSenha.Size = new Size(238, 23);
            txtSenha.TabIndex = 1;
            txtSenha.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Cursor = Cursors.Hand;
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.CornflowerBlue;
            label2.Location = new Point(42, 169);
            label2.Name = "label2";
            label2.Size = new Size(51, 20);
            label2.TabIndex = 3;
            label2.Text = "Senha";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnEntrar
            // 
            btnEntrar.Anchor = AnchorStyles.None;
            btnEntrar.BackColor = Color.White;
            btnEntrar.Cursor = Cursors.Hand;
            btnEntrar.ForeColor = Color.CornflowerBlue;
            btnEntrar.Location = new Point(43, 238);
            btnEntrar.Name = "btnEntrar";
            btnEntrar.Size = new Size(238, 25);
            btnEntrar.TabIndex = 4;
            btnEntrar.Text = "ENTRAR";
            btnEntrar.UseVisualStyleBackColor = false;
            btnEntrar.Click += btnEntrar_Click;
            btnEntrar.KeyPress += btnEntrar_KeyPress;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.CornflowerBlue;
            label3.Location = new Point(42, 4);
            label3.Name = "label3";
            label3.Size = new Size(239, 32);
            label3.TabIndex = 6;
            label3.Text = "MERCADÃO BUGIU ";
            label3.TextAlign = ContentAlignment.TopCenter;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.CornflowerBlue;
            label1.Location = new Point(42, 91);
            label1.Name = "label1";
            label1.Size = new Size(48, 20);
            label1.TabIndex = 8;
            label1.Text = "Login";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txtLogin
            // 
            txtLogin.Anchor = AnchorStyles.None;
            txtLogin.BorderStyle = BorderStyle.FixedSingle;
            txtLogin.Location = new Point(42, 114);
            txtLogin.Name = "txtLogin";
            txtLogin.Size = new Size(238, 23);
            txtLogin.TabIndex = 9;
            txtLogin.TextAlign = HorizontalAlignment.Center;
            // 
            // pnlContainer
            // 
            pnlContainer.BackColor = Color.MidnightBlue;
            pnlContainer.Controls.Add(btnEntrar);
            pnlContainer.Controls.Add(label3);
            pnlContainer.Controls.Add(label1);
            pnlContainer.Controls.Add(txtSenha);
            pnlContainer.Controls.Add(txtLogin);
            pnlContainer.Controls.Add(label2);
            pnlContainer.Location = new Point(126, 5);
            pnlContainer.Name = "pnlContainer";
            pnlContainer.Size = new Size(320, 328);
            pnlContainer.TabIndex = 10;
            // 
            // TelaLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MidnightBlue;
            ClientSize = new Size(593, 345);
            Controls.Add(pnlContainer);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Name = "TelaLogin";
            Text = "TelaLogin";
            pnlContainer.ResumeLayout(false);
            pnlContainer.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private TextBox txtSenha;
        private Label label2;
        private Button btnEntrar;
        private Label label3;
        private Label label1;
        private TextBox txtLogin;
        private Panel pnlContainer;
    }
}