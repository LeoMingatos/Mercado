﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MERCADOPOO.Model
{
    public class ItemVenda
    {
        public int IdItem { get; set; }
        public int IdVenda { get; set; }
        public string IdProduto { get; set; }
        public int Quantidade { get; set; }
        public decimal Subtotal { get; set; }


        public string NomeProduto { get; set; }
        public decimal PrecoUnitario { get; set; }
    }
}
