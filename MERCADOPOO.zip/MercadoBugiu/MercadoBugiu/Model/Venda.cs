﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MERCADOPOO.Model
{
    public class Venda
    {
        public int IdVenda { get; set; }
        public DateTime DataVenda { get; set; }
        public int IdCliente { get; set; }
        public int IdUsuario { get; set; }
        public decimal ValorTotal { get; set; }

        // Esta lista representa todos os produtos e quantidades vendidas nesta transação(Carrinho)
        public List<ItemVenda> ItensVenda { get; set; } = new List<ItemVenda>();
    }
}
