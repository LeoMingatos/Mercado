﻿using MERCADOPOO.Controller;
using MERCADOPOO.Model;
using MERCADOPOO.Util; // SessaoAtual está aqui,
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data; 

namespace MERCADOPOO
{
    // Formulário de Cadastro e Edição de Usuários.
    public partial class CadUsuario : Form
    {
        // Instância do Controller para acesso à lógica de negócio e banco de dados.
        UsuarioController usuarioController = new UsuarioController();

        public CadUsuario()
        {
            InitializeComponent();
            CarregarUsuarios();      // Carrega a lista de usuários na DGV.
            CarregarNiveisAcesso();  // Preenche o ComboBox de cargos.
            LimparCampos();          // Limpa os campos iniciais.
        }

        // --- FUNÇÕES DE ROTINA ---

        // Função para definir o nível de acesso dos usuários no ComboBox.
        private void CarregarNiveisAcesso()
        {
            List<string> niveis = new List<string>
            {
                "Administrador", "Gerente", "Financeiro", "Estoque", "Caixa"
            };
            cboNivelAcesso.DataSource = niveis;
            cboNivelAcesso.SelectedIndex = -1;
        }

        // Carrega todos os usuários no DataGridView.
        private void CarregarUsuarios()
        {
            dgvUsuarios.DataSource = usuarioController.GetAll();
        }

        // Limpa todos os campos de texto e reseta o ComboBox de nível de acesso.
        private void LimparCampos()
        {
            txtIdUsuario.Clear();
            txtNome.Clear();
            txtLogin.Clear();
            txtSenha.Clear();
            cboNivelAcesso.SelectedIndex = -1;
         
        }

        // --- EVENTOS DA INTERFACE ---

        // Botão NOVO (Prepara o formulário para um novo cadastro).
        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        // Botão SALVAR (Faz a lógica unificada de INSERIR ou ALTERAR).
        private void btnSalvar_Click_1(object sender, EventArgs e)
        {
            // Validações Essenciais
            if (string.IsNullOrWhiteSpace(txtNome.Text)) { MessageBox.Show("Preencha o Nome!"); txtNome.Focus(); return; }
            if (string.IsNullOrWhiteSpace(txtLogin.Text) || string.IsNullOrWhiteSpace(txtSenha.Text)) { MessageBox.Show("Login e Senha são obrigatórios!"); return; }
            if (cboNivelAcesso.SelectedIndex == -1) { MessageBox.Show("Selecione um Nível de Acesso (Cargo) para o usuário!"); cboNivelAcesso.Focus(); return; }

            // Verifica se é uma ALTERAÇÃO (ID preenchido) ou uma INSERÇÃO (ID vazio)
            bool isUpdate = int.TryParse(txtIdUsuario.Text, out int idUsuarioExistente);

            // Prepara o objeto
            Usuario u = new Usuario
            {
                IdUsuario = isUpdate ? idUsuarioExistente : 0,
                Nome = txtNome.Text,
                Login = txtLogin.Text,
                Senha = txtSenha.Text,
                NivelAcesso = cboNivelAcesso.Text
            };

            // Lógica de Persistência
            try
            {
                if (isUpdate)
                {
                    usuarioController.Alterar(u);
                    MessageBox.Show("Usuário atualizado com sucesso!");
                }
                else
                {
                    usuarioController.Inserir(u);
                    MessageBox.Show("Usuário cadastrado com sucesso!");
                }
            }
            catch (SqlException sqlex)
            {
                if (sqlex.Number == 2627) // Trata erro de Login Duplicado (restrição UNIQUE)
                {
                    MessageBox.Show($"Erro: Já existe um usuário com o Login '{u.Login}'.", "Login Duplicado");
                    return;
                }
                MessageBox.Show("Erro de banco de dados: " + sqlex.Message, "Erro SQL");
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar usuário: " + ex.Message, "Erro Geral");
                return;
            }

            CarregarUsuarios();
            LimparCampos();
        }

        // Botão EXCLUIR
        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtIdUsuario.Text))
            {
                MessageBox.Show("Selecione um usuário para excluir.");
                return;
            }

            if (int.TryParse(txtIdUsuario.Text, out int id))
            {
                usuarioController.Excluir(id);
                MessageBox.Show("Usuário excluído com sucesso!");
                CarregarUsuarios();
                LimparCampos();
            }
            else
            {
                MessageBox.Show("Erro: O campo ID do Usuário deve conter um número válido para exclusão. Verifique a seleção.");
            }
        }

        // LÓGICA DE PESQUISA (Abre a tela  SeleUsuario)
        private void btnPesquisar_Click_1(object sender, EventArgs e)
        {
           
            using (SeleUsuario SelePesquisa = new SeleUsuario())
            {
                if (SelePesquisa.ShowDialog() == DialogResult.OK)
                {
                    Usuario usuarioSelecionado = SelePesquisa.UsuarioSelecionado;

                    if (usuarioSelecionado != null)
                    {
                        // Preenche os campos de EDIÇÃO/CADASTRO com os dados retornados
                        txtIdUsuario.Text = usuarioSelecionado.IdUsuario.ToString();
                        txtNome.Text = usuarioSelecionado.Nome;
                        txtLogin.Text = usuarioSelecionado.Login;
                        txtSenha.Text = usuarioSelecionado.Senha;
                        cboNivelAcesso.Text = usuarioSelecionado.NivelAcesso;

                        // Atualiza a grade para mostrar apenas este usuário
                         dgvUsuarios.DataSource = usuarioController.GetById(usuarioSelecionado.IdUsuario);
                    }
                    else
                    {
                        // Recarrega a grade completa se nada foi selecionado
                        CarregarUsuarios();
                    }
                }
            }
        }

        // Carrega os dados da linha para os campos de edição
        private void dgvUsuarios_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvUsuarios.Rows[e.RowIndex];

            txtIdUsuario.Text = row.Cells["IdUsuario"].Value.ToString();
            txtNome.Text = row.Cells["Nome"].Value.ToString();
            txtLogin.Text = row.Cells["Login"].Value.ToString();
            txtSenha.Text = row.Cells["Senha"].Value.ToString();
            cboNivelAcesso.Text = row.Cells["NivelAcesso"].Value.ToString();
        }
    }
}