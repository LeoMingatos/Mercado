﻿using MERCADOPOO.Controller;
using MERCADOPOO.Model;
using MERCADOPOO.Services;
using System;
using System.Collections.Generic; 
using System.Linq; 
using System.Windows.Forms;
using System.Text.RegularExpressions; 
namespace MERCADOPOO
{
    // Formulário de Cadastro e Edição de Clientes.
    public partial class CadCliente : Form
    {
        // Instância do Controller para acesso à lógica de negócio e banco de dados.
        private readonly ClienteController controller = new ClienteController();

        public CadCliente()
        {
            InitializeComponent();
            AtualizarGrid(); // Carrega a lista de clientes ao iniciar o formulário.
        }

        // --- FUNÇÕES DE ROTINA ---
        
        // Recarrega todos os clientes no DataGridView (tabela).
        private void AtualizarGrid()
        {
            dgvClientes.DataSource = null;
            dgvClientes.DataSource = controller.GetAll(); // Pega todos os clientes do Controller.
        }

        // Define todos os campos de texto como vazios e coloca o foco no Nome.
        private void LimparCampos()
        {
            txtId.Clear();
            txtNome.Clear();
            txtCpf.Clear();
            txtTelefone.Clear();
            txtEmail.Clear();
            txtNome.Focus();
        }

        // --- FUNÇÕES DE VALIDAÇÃO ---

        // Checa se o CPF tem 11 dígitos e se é apenas numérico (validação de formato).
        private bool IsCpfValido(string cpf)
        {
            string cpfLimpo = cpf.Replace(".", "").Replace("-", "").Trim();

            if (cpfLimpo.Length != 11 || !long.TryParse(cpfLimpo, out _))
            {
                return false;
            }
            return true;
        }

        // Validação de E-mail (checa o formato com Regex).
        private bool IsEmailValido(string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return true; // Permite se for vazio

            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            try
            {
                return System.Text.RegularExpressions.Regex.IsMatch(email, pattern);
            }
            catch
            {
                return false;
            }
        }

        // Validação de Telefone (checa se o número de dígitos está entre 8 e 11).
        private bool IsTelefoneValido(string telefone)
        {
            if (string.IsNullOrWhiteSpace(telefone)) return true; // Permite se for vazio

            // Remove caracteres não-numéricos
            string telefoneLimpo = new string(telefone.Where(char.IsDigit).ToArray());

            return telefoneLimpo.Length >= 8 && telefoneLimpo.Length <= 11;
        }

        // --- EVENTOS DA INTERFACE ---

        // Botão NOVO (Limpa os campos para um novo registro)
        private void btnNovo_Click_1(object sender, EventArgs e)
        {
            LimparCampos();
        }

        // Evento: Botão SALVAR (Faz a lógica unificada de INSERIR ou ALTERAR)
        private void btnSalvar_Click1(object sender, EventArgs e)
        {
            // Validações Essenciais
            if (string.IsNullOrWhiteSpace(txtNome.Text)) { MessageBox.Show("Preencha o nome!"); txtNome.Focus(); return; }
            if (!IsCpfValido(txtCpf.Text)) { MessageBox.Show("O CPF inserido é inválido."); txtCpf.Focus(); return; }
            if (!IsEmailValido(txtEmail.Text)) { MessageBox.Show("O E-mail inserido é inválido."); txtEmail.Focus(); return; }
            if (!IsTelefoneValido(txtTelefone.Text)) { MessageBox.Show("O Telefone inserido é inválido."); txtTelefone.Focus(); return; }

            // Cria o objeto Cliente com os dados dos campos
            Cliente cliente = new Cliente
            {
                Nome = txtNome.Text,
                CPF = txtCpf.Text,
                Telefone = txtTelefone.Text,
                Email = txtEmail.Text
            };

            // Lógica de Decisão: INSERIR ou ALTERAR
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                // INSERIR NOVO
                controller.Inserir(cliente);
                MessageBox.Show("Cliente cadastrado com sucesso!");
            }
            else
            {
                // ALTERAR EXISTENTE
                cliente.IdCliente = Convert.ToInt32(txtId.Text);
                controller.Alterar(cliente);
                MessageBox.Show("Cliente atualizado com sucesso!");
            }

            AtualizarGrid(); // Recarrega a tabela
            LimparCampos(); // Limpa os campos
        }


        // Botão PESQUISAR (Abre a tela para selecionar um cliente)
        private void btnPesquisar_Click_1(object sender, EventArgs e)
        {
            
            using (SeleCliente SelePesquisa = new SeleCliente())
            {
                // Abre o formulário 
                if (SelePesquisa.ShowDialog() == DialogResult.OK)
                {
                    Cliente clienteSelecionado = SelePesquisa.ClienteSelecionado;

                    if (clienteSelecionado != null)
                    {
                        // Se um cliente foi selecionado, preenche os campos com os dados retornados
                        txtId.Text = clienteSelecionado.IdCliente.ToString();
                        txtNome.Text = clienteSelecionado.Nome;
                        txtCpf.Text = clienteSelecionado.CPF;
                        txtTelefone.Text = clienteSelecionado.Telefone;
                        txtEmail.Text = clienteSelecionado.Email;

                        // Atualiza a grade para mostrar apenas esse cliente 
                        dgvClientes.DataSource = new List<Cliente> { clienteSelecionado };
                    }
                    else
                    {
                        // Se o usuário fechou ou cancelou, recarrega a grid completa
                        AtualizarGrid();
                    }
                }
            }
        }

        // Botão EXCLUIR
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                MessageBox.Show("Selecione um cliente para excluir!");
                return;
            }

            int id = Convert.ToInt32(txtId.Text);
            controller.Excluir(id); // Chama o controller para deletar

            MessageBox.Show("Cliente excluído com sucesso!");
            AtualizarGrid();
            LimparCampos();
        }

        // Clique em uma célula da tabela (carrega dados para edição)
        private void dgvClientes_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvClientes.Rows[e.RowIndex];
            
            // Pega os dados da linha e preenche os campos
            txtId.Text = row.Cells["IdCliente"].Value.ToString();
            txtNome.Text = row.Cells["Nome"].Value.ToString();
            txtCpf.Text = row.Cells["CPF"].Value.ToString();
            txtTelefone.Text = row.Cells["Telefone"].Value.ToString();
            txtEmail.Text = row.Cells["Email"].Value.ToString();
        }

    }
}