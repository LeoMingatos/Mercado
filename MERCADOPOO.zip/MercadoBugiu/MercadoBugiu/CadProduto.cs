﻿using MERCADOPOO.Controller;
using MERCADOPOO.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace MERCADOPOO
{
    // Formulário de Cadastro, Edição e Exclusão de Produtos.
    public partial class CadProduto : Form
    {
        // Instâncias dos Controllers
        private readonly ProdutoController produtoController = new ProdutoController();
        //Para puxar automaticamente os fornecedores de cada produto
        private readonly FornecedorController fornecedorController = new FornecedorController();

        public CadProduto()
        {
            InitializeComponent();
            CarregarFornecedores(); // Carrega os fornecedores no ComboBox
            AtualizarGrid(); // Carrega a lista de produtos ao iniciar
        }


        // Valida o Código de Barras (EAN-13).
        // Checa formato, 13 dígitos e o dígito verificador.
        private bool IsCodigoDeBarrasValido(string idProdutoString)
        {
            // Validação de formato e comprimento
            if (string.IsNullOrWhiteSpace(idProdutoString) || idProdutoString.Length != 13 || !idProdutoString.All(char.IsDigit))
            {
                return false;
            }

            int sum = 0;

            // Loop para calcular o dígito verificador (regra EAN-13)
            for (int i = 0; i < 12; i++)
            {
                int digit = int.Parse(idProdutoString[i].ToString());
                // Posições ímpares (*1), posições pares (*3)
                sum += digit * (i % 2 == 0 ? 1 : 3);
            }

            int remainder = sum % 10;
            int checkDigit = (10 - remainder) % 10; // Dígito verificador calculado

            int lastDigit = int.Parse(idProdutoString[12].ToString()); // Último dígito inserido

            return checkDigit == lastDigit; // Compara calculado com inserido
        }

        // Pega a lista completa de fornecedores e preenche o ComboBox.
        private void CarregarFornecedores()
        {
            cmbFornecedor.DataSource = fornecedorController.GetAll();
            cmbFornecedor.DisplayMember = "RazaoSocial"; // O que o usuário vê
            cmbFornecedor.ValueMember = "IdFornecedor"; // O valor real
        }

        // Limpa e recarrega todos os produtos no DataGridView.
        private void AtualizarGrid()
        {
            dgvProdutos.DataSource = null;
            dgvProdutos.DataSource = produtoController.GetAll();
        }

        // Define todos os campos de texto como vazios e desmarca o fornecedor.
        private void LimparCampos()
        {
            txtId.Clear();
            txtNome.Clear();
            txtPreco.Clear();
            txtEstoque.Clear();
            cmbFornecedor.SelectedIndex = -1;
        }

        // --- EVENTOS DA INTERFACE ---

        // Botão NOVO (Prepara o formulário para um novo cadastro).
        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        // Botão SALVAR (Faz a lógica unificada de INSERIR ou ALTERAR).
        private void btnSalvar_Click(object sender, EventArgs e)
        {
            // Validações Essenciais
            if (string.IsNullOrWhiteSpace(txtNome.Text)) { MessageBox.Show("Preencha o nome do produto!"); txtNome.Focus(); return; }
            if (cmbFornecedor.SelectedValue == null) { MessageBox.Show("Selecione um Fornecedor válido!"); cmbFornecedor.Focus(); return; }

            string idText = txtId.Text.Trim();

            if (!long.TryParse(idText, out long idProduto)) { MessageBox.Show("O ID (código de barras) deve ser um número válido."); txtId.Focus(); return; }
            if (!IsCodigoDeBarrasValido(idText)) { MessageBox.Show("O Código de Barras é inválido."); txtId.Focus(); return; }
            if (!decimal.TryParse(txtPreco.Text, out decimal preco)) { MessageBox.Show("O preço inserido é inválido."); txtPreco.Focus(); return; }
            if (!int.TryParse(txtEstoque.Text, out int estoque)) { MessageBox.Show("O estoque inserido é inválido."); txtEstoque.Focus(); return; }

            Produto produto = new Produto
            {
                IdProduto = idProduto,
                Nome = txtNome.Text,
                Preco = preco,
                Estoque = estoque,
                IdFornecedor = (int)cmbFornecedor.SelectedValue
            };

            // Lógica de Decisão: INSERIR ou ALTERAR
            if (produtoController.GetById(produto.IdProduto) == null)
            {
                // INSERIR: Se o produto NÃO existe no banco
                try
                {
                    produtoController.Inserir(produto);
                    MessageBox.Show("Produto cadastrado com sucesso!");
                }
                catch (SqlException sqlex)
                {
                    // Tratamento de erros comuns de banco de dados (duplicidade/chave estrangeira)
                    if (sqlex.Number == 2627) { MessageBox.Show($"Erro: Já existe um produto com o ID {produto.IdProduto}."); }
                    else if (sqlex.Number == 547) { MessageBox.Show("Erro de Chave Estrangeira: O Fornecedor selecionado não existe."); }
                    else { MessageBox.Show("Erro de banco de dados ao inserir produto: " + sqlex.Message); }
                    return;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao inserir produto: " + ex.Message);
                    return;
                }
            }
            else
            {
                // ALTERAR: Se o produto JÁ existe no banco
                try
                {
                    produtoController.Alterar(produto);
                    MessageBox.Show("Produto atualizado com sucesso!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao atualizar produto: " + ex.Message);
                    return;
                }
            }

            AtualizarGrid();
            LimparCampos();
        }

        // Botão EXCLUIR
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text)) { MessageBox.Show("Selecione um produto ou digite o ID para excluir!"); txtId.Focus(); return; }
            if (!long.TryParse(txtId.Text, out long idParaExcluir)) { MessageBox.Show("O ID inserido é inválido."); txtId.Focus(); return; }


            DialogResult confirmacao = MessageBox.Show(
                $"Tem certeza que deseja excluir o produto com ID {idParaExcluir}?",
                "Confirmar Exclusão",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirmacao == DialogResult.Yes)
            {
                try
                {
                    int linhasAfetadas = produtoController.Excluir(idParaExcluir);

                    if (linhasAfetadas > 0)
                    {
                        MessageBox.Show("Produto excluído com sucesso!");
                    }
                    else
                    {
                        MessageBox.Show("Nenhum produto encontrado com o ID especificado.");
                    }
                }
                catch (SqlException sqlex)
                {
                    if (sqlex.Number == 547)
                    {
                        MessageBox.Show("Erro: Este produto não pode ser excluído pois está sendo referenciado em outras tabelas (Ex: Vendas).");
                    }
                    else
                    {
                        MessageBox.Show("Erro de banco de dados: " + sqlex.Message);
                    }
                    return;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao excluir produto: " + ex.Message);
                    return;
                }

                AtualizarGrid();
                LimparCampos();
            }
        }

        // Botão PESQUISAR (Abre a tela  de seleção de produto)
        private void btnPesquisar_Click_1(object sender, EventArgs e)
        {
            // Instancia e abre o formulário de pesquisa de produtos
            using (PesquisaProduto SelePesquisa = new PesquisaProduto()) 
            {
                if (SelePesquisa.ShowDialog() == DialogResult.OK)
                {
                    Produto produtoSelecionado = SelePesquisa.ProdutoSelecionado;

                    if (produtoSelecionado != null)
                    {
                        // Limpa os campos antes de preencher
                        LimparCampos();

                        // Preenche os campos do formulário principal com os dados do produto
                        txtId.Text = produtoSelecionado.IdProduto.ToString();
                        txtNome.Text = produtoSelecionado.Nome;
                        txtPreco.Text = produtoSelecionado.Preco.ToString();
                        txtEstoque.Text = produtoSelecionado.Estoque.ToString();

                        // Seleciona o fornecedor correto no ComboBox
                        cmbFornecedor.SelectedValue = produtoSelecionado.IdFornecedor;

                        // Atualiza a grade para mostrar apenas o item selecionado 
                        dgvProdutos.DataSource = new List<Produto> { produtoSelecionado };
                    }
                    else
                    {
                        AtualizarGrid();
                    }
                }
            }
        }

        // Clique em uma célula da tabela (carrega dados para edição)
        private void dgvProdutos_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvProdutos.Rows[e.RowIndex];

            // Pega os dados da linha e preenche os campos
            long idProduto = Convert.ToInt64(row.Cells["IdProduto"].Value);
            txtId.Text = idProduto.ToString();

            int idFornecedor = Convert.ToInt32(row.Cells["IdFornecedor"].Value);
            cmbFornecedor.SelectedValue = idFornecedor;

            int estoque = Convert.ToInt32(row.Cells["Estoque"].Value);
            txtEstoque.Text = estoque.ToString();

            decimal preco = Convert.ToDecimal(row.Cells["Preco"].Value);
            txtPreco.Text = preco.ToString();

            txtNome.Text = row.Cells["Nome"].Value.ToString();
        }
    }
}