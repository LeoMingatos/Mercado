﻿using MERCADOPOO.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MERCADOPOO
{
    // Formulário de consulta e filtro do histórico de vendas.
    public partial class HistoricoVendas : Form
    {
        private readonly VendaController vendaController = new VendaController();

       
        // Armazena o ID do Produto (long? para aceitar null)
        private long? filtroIdProduto = null;
        // Armazena o ID do Fornecedor (int? para aceitar null)
        private int? filtroIdFornecedor = null;


        public HistoricoVendas()
        {
            InitializeComponent();
            ConfigurarDatasIniciais();
            CarregarHistoricoTotal(); // Carrega os dados iniciais ao abrir
        }

        // Define as datas de início e fim padrão (últimos 30 dias).
        private void ConfigurarDatasIniciais()
        {
            dtpDataFim.Value = DateTime.Now;
            dtpDataInicio.Value = DateTime.Now.AddDays(-30);
        }

        // Carrega o histórico de vendas total (desde 1900) para iniciar a consulta.
        private void CarregarHistoricoTotal()
        {
            // Data mínima segura para o SQL Server 
            DateTime dataInicioSegura = new DateTime(1900, 1, 1);
            DateTime dataFim = DateTime.Now;

            try
            {
                // Chama o método do Controller sem filtros de ID (Produto/Fornecedor = null)
                dgvHistorico.DataSource = vendaController.GetVendasFiltradas(dataInicioSegura, dataFim, null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar o histórico: " + ex.Message, "Erro de Sistema");
            }
        }

        // --- EVENTO PRINCIPAL DE FILTRO ---

        // Botão FILTRAR (Aplica todos os filtros: Data, Produto, Fornecedor).
        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            DateTime dataInicio = dtpDataInicio.Value.Date;
            DateTime dataFim = dtpDataFim.Value.Date;

            // Validação de datas
            if (dataInicio > dataFim)
            {
                MessageBox.Show("A Data Inicial não pode ser maior que a Data Final.", "Erro de Filtro");
                return;
            }

            // LÊ E CONVERTE OS IDs DOS CAMPOS DE TEXTO
            long idProd;
            int idForn;

            // Tenta ler o ID do Produto (txtProdutoIdFiltro) e converte para long?
            filtroIdProduto = long.TryParse(txtProdutoIdFiltro.Text, out idProd) ? idProd : (long?)null;

            // Tenta ler o ID do Fornecedor (txtFornecedorIdFiltro) e converte para int?
            filtroIdFornecedor = int.TryParse(txtFornecedorIdFiltro.Text, out idForn) ? idForn : (int?)null;


            try
            {
                // CHAMA O MÉTODO CONSOLIDADO NO CONTROLLER
                dgvHistorico.DataSource = vendaController.GetVendasFiltradas(
                    dataInicio,
                    dataFim,
                    filtroIdProduto,
                    filtroIdFornecedor
                );

                if (dgvHistorico.Rows.Count == 0)
                {
                    MessageBox.Show("Nenhuma venda encontrada com os filtros selecionados.", "Resultado Vazio");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao aplicar o filtro: " + ex.Message, "Erro de Sistema");
            }
        }

        // --- VISUALIZAÇÃO DE DETALHES ---

        // Clique na célula da tabela (usado para exibir detalhes da venda).
        private void dgvHistorico_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            // Pega o ID da venda
            DataGridViewRow row = dgvHistorico.Rows[e.RowIndex];
            int idVenda = Convert.ToInt32(row.Cells["IdVenda"].Value);

            
        }

        
    }
}