﻿using MERCADOPOO.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MERCADOPOO
{
    // Formulário para consultar e visualizar o estoque atual de produtos.
    public partial class TelaEstoque : Form
    {
        // Instância do Controller de Produto, usado para acessar os dados do estoque.
        private readonly ProdutoController produtoController = new ProdutoController();

        public TelaEstoque()
        {
            InitializeComponent();
            CarregarEstoque(""); // Carrega todos os produtos ao iniciar 
        }

        // --- FUNÇÕES DE CONSULTA ---
    
        //Busca produtos no estoque pelo termo de pesquisa (Nome, Marca ou ID) e carrega a DataGridView.
       
        private void CarregarEstoque(string termoBusca)
        {
            try
            {
                // Chama o método do Controller que faz a busca combinada (Nome, Marca, ID)
                 dgvEstoque.DataSource = produtoController.GetEstoqueComFiltro(termoBusca);

                // Feedback visual caso a busca retorne vazio
                if (dgvEstoque.Rows.Count == 0 && !string.IsNullOrWhiteSpace(termoBusca))
                {
                    MessageBox.Show("Nenhum produto encontrado com o filtro aplicado.", "Busca Vazia");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao consultar o estoque: " + ex.Message, "Erro de Sistema");
            }
        }

        // --- EVENTOS DA INTERFACE ---

        // Botão BUSCAR.
        // Aciona a pesquisa com o termo digitado.
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string termo = txtPesquisa.Text.Trim();
            CarregarEstoque(termo);
        }

        //Botão LIMPAR.
        //Limpa o campo de pesquisa e recarrega o estoque total.
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPesquisa.Clear();
            CarregarEstoque(""); // Recarrega com termo vazio (todos os produtos)
        }
    }
}