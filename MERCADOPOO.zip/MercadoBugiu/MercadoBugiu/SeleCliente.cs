﻿using MERCADOPOO.Controller;
using MERCADOPOO.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace MERCADOPOO
{
    // Formulário para pesquisar e selecionar um único cliente 
    public partial class SeleCliente : Form
    {
        // Controller para acesso aos dados do cliente
        private readonly ClienteController controller = new ClienteController();

        // Propriedade pública para retornar o objeto Cliente selecionado ao formulário chamador.
        public Cliente ClienteSelecionado { get; private set; }

        public SeleCliente()
        {
            InitializeComponent();
            CarregarTodosClientes();
            // Configura a DGV para selecionar a linha inteira ao clicar
            dgvResultados.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvResultados.MultiSelect = false;
        }

        // --- FUNÇÕES DE ROTINA ---

        // Carrega a lista completa de clientes na DataGridView.
        private void CarregarTodosClientes()
        {
            dgvResultados.DataSource = controller.GetAll();
        }

        // --- LÓGICA DE PESQUISA E SELEÇÃO ---

        // Botão Buscar
        // //Pesquisa por Nome do Cliente.
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            
            string nomeBusca = txtCliente.Text.Trim();

            if (string.IsNullOrWhiteSpace(nomeBusca))
            {
                CarregarTodosClientes(); // Se a busca estiver vazia, recarrega tudo
                return;
            }

            // Chama o método do Controller para buscar por nome
            dgvResultados.DataSource = controller.GetByName(nomeBusca);

            if (dgvResultados.Rows.Count == 0)
            {
                MessageBox.Show($"Nenhum cliente encontrado com o nome '{nomeBusca}'.", "Busca Vazia");
            }
        }

        // Duplo clique na linha do DataGridView (Duplo clique deve selecionar e fechar)
        private void dgvResultados_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            SelecionarCliente();
        }

      

    
        private void btnSelecionar_Click(object sender, EventArgs e)
        {
            SelecionarCliente();
        }


        // Lógica principal que pega o cliente selecionado e define o retorno.
        private void SelecionarCliente()
        {
            // 1Verifica se há alguma linha selecionada
            if (dgvResultados.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecione um cliente na lista.");
                return;
            }

            // Pega a primeira linha selecionada
            DataGridViewRow row = dgvResultados.SelectedRows[0];

            // Pega o ID do cliente da célula (deve ser o IdCliente)
            string idClienteString = row.Cells["IdCliente"].Value.ToString();

            // Validação e Busca do Objeto Completo
            if (!int.TryParse(idClienteString, out int idCliente))
            {
                MessageBox.Show("Erro: O ID do cliente selecionado não é um número válido.", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Busca o objeto Cliente completo 
            ClienteSelecionado = controller.GetById(idCliente);

            // Define o resultado e fecha o formulário
            this.DialogResult = DialogResult.OK; // Indica sucesso na seleção
            this.Close();
        }
    }
}