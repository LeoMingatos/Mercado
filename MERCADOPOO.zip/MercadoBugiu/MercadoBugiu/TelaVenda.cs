﻿using MERCADOPOO.Controller;
using MERCADOPOO.Model;
using MERCADOPOO.Util; // Classe estática para gerenciar o usuário logado
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Data.SqlClient; // Necessário para SqlException (embora não esteja no using listado, é crucial para o try/catch)

namespace MERCADOPOO
{
    // Formulário do Ponto de Venda (PDV) para registrar transações.
    public partial class TelaVenda : Form
    {
        // --- INSTÂNCIAS DOS CONTROLLERS ---
        VendaController controller = new VendaController();
        ClienteController clienteController = new ClienteController();
        UsuarioController usuarioController = new UsuarioController();
        ProdutoController produtoController = new ProdutoController();
        FornecedorController fornecedorController = new FornecedorController();
        ItemVendaController itemVendaController = new ItemVendaController();

        // --- Variáveis de Classe ---
        private List<ItemVenda> carrinho = new List<ItemVenda>(); // O carrinho de compras em memória

        public TelaVenda()
        {
            InitializeComponent();
            CarregarClientes();
            CarregarUsuarios();
            AtualizarGrid();      // Carrega o histórico de vendas (grid principal)
            AtualizarGridItens(); // Inicializa o carrinho vazio
        }

        // --- FUNÇÕES DE CARREGAMENTO E LIMPEZA ---

        // Carrega a lista de clientes no ComboBox.
        private void CarregarClientes()
        {
            cmbCliente.DataSource = clienteController.GetAll();
            cmbCliente.DisplayMember = "Nome";
            cmbCliente.ValueMember = "IdCliente";
            cmbCliente.SelectedIndex = -1;
        }

        // Carrega os usuários e pré-seleciona o usuário logado (Operador).
        private void CarregarUsuarios()
        {
            cmbUsuario.DataSource = usuarioController.GetAll();
            cmbUsuario.DisplayMember = "Nome";
            cmbUsuario.ValueMember = "IdUsuario";

            try
            {
                cmbUsuario.SelectedValue = SessaoAtual.IdUsuarioLogado;
                cmbUsuario.Enabled = false; // Bloqueia a alteração do usuário logado
            }
            catch
            {
                cmbUsuario.SelectedIndex = -1;
                cmbUsuario.Enabled = true;
            }
        }

        // Recarrega todas as vendas na grid principal (dgvVendas).
        private void AtualizarGrid()
        {
            dgvVendas.DataSource = null;
            dgvVendas.DataSource = controller.GetAll();
        }

        // Recalcula o total e preenche a grid de itens (o carrinho).
        private void AtualizarGridItens()
        {
            dgvItensVenda.DataSource = null;

            // Mapeia a lista de itens para exibição no DataGridView
            dgvItensVenda.DataSource = carrinho.Select(i => new
            {
                ID_Produto = i.IdProduto,
                Produto = i.NomeProduto,
                Qtd = i.Quantidade,
                Unitario = i.PrecoUnitario.ToString("N2"),
                Subtotal = (i.Quantidade * i.PrecoUnitario).ToString("N2")
            }).ToList();

            // Calcula a soma total do carrinho
            decimal totalVenda = carrinho.Sum(i => i.Quantidade * i.PrecoUnitario);
            txtValorTotal.Text = totalVenda.ToString("N2");
        }

        // Limpa todos os campos da transação (cabeçalho e carrinho).
        private void LimparCampos()
        {
            txtId.Clear();
            dtpDataVenda.Value = DateTime.Now;
            cmbCliente.SelectedIndex = -1;

            txtValorTotal.Clear();
            txtProdutoId.Clear();
            txtQuantidade.Clear();
            txtNomeProduto.Clear();
            txtFornecedorProduto.Clear();

            carrinho.Clear();      // Limpa a lista em memória
            AtualizarGridItens(); // Atualiza a grid para refletir o carrinho vazio
            txtProdutoId.Focus();
        }

        // --- EVENTOS DE INTERAÇÃO (PRODUTO E CARRINHO) ---

        // Evento: Busca detalhes do produto ao sair do campo ID (digitação/scanner).
        private void txtProdutoId_Leave(object sender, EventArgs e)
        {
            string idProdutoString = txtProdutoId.Text.Trim();

            txtNomeProduto.Clear();
            txtFornecedorProduto.Clear();

            if (string.IsNullOrWhiteSpace(idProdutoString)) return;

            try
            {
                // Valida e converte o ID para long
                if (!long.TryParse(idProdutoString, out long idProdutoLong))
                {
                    MessageBox.Show("O Código de Barras deve ser um número longo válido.", "Erro de Formato");
                    return;
                }

                Produto produto = produtoController.GetById(idProdutoLong);

                if (produto != null)
                {
                    txtNomeProduto.Text = produto.Nome;

                    // Busca o fornecedor para exibição
                    int idFornecedor = Convert.ToInt32(produto.IdFornecedor);
                    Fornecedor fornecedor = fornecedorController.GetById(idFornecedor);

                    txtFornecedorProduto.Text = fornecedor?.RazaoSocial ?? "[Não cadastrado]";

                    txtQuantidade.Focus();
                }
                else
                {
                    txtNomeProduto.Text = "Produto Não Encontrado";
                    MessageBox.Show("Nenhum produto encontrado com o código digitado.", "Busca Falhou");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao buscar o produto: " + ex.Message, "Erro de Sistema");
            }
        }




        // Abre o formulário de pesquisa 
        private void btnAbrirPesquisa_Click(object sender, EventArgs e)
        {
            using (PesquisaProduto frmPesquisa = new PesquisaProduto())
            {
                if (frmPesquisa.ShowDialog() == DialogResult.OK)
                {
                    Produto produtoEscolhido = frmPesquisa.ProdutoSelecionado;

                    if (produtoEscolhido != null)
                    {
                        txtProdutoId.Text = produtoEscolhido.IdProduto.ToString();
                        // Força o preenchimento dos detalhes
                        txtProdutoId_Leave(txtProdutoId, EventArgs.Empty);
                    }
                }
            }
        }

        // --- EVENTOS DE BOTÃO PRINCIPAL (VENDER / NOVO / EXCLUIR) ---

        // NOVO: Para resetar o formulário
        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        // VENDER: Finaliza a transação, insere no DB e atualiza estoque
        private void btnVender_Click(object sender, EventArgs e)
        {
            // 1. Validações
            if (cmbCliente.SelectedIndex < 0) { MessageBox.Show("Selecione o Cliente!"); return; }
            if (carrinho.Count == 0) { MessageBox.Show("Adicione pelo menos um produto à venda para finalizar!", "Erro de Transação"); return; }
            if (!decimal.TryParse(txtValorTotal.Text.Replace("R$", "").Replace(".", "").Replace(",", "."), out decimal valorTotal)) { MessageBox.Show("Erro ao ler o Valor Total.", "Erro"); return; }
            if (!string.IsNullOrWhiteSpace(txtId.Text)) { MessageBox.Show("Você está tentando finalizar uma venda existente.", "Erro de Fluxo"); return; }

            // Prepara e insere o cabeçalho
            Venda venda = new Venda
            {
                DataVenda = dtpDataVenda.Value,
                IdCliente = Convert.ToInt32(cmbCliente.SelectedValue),
                IdUsuario = Convert.ToInt32(cmbUsuario.SelectedValue),
                ValorTotal = valorTotal
            };

            int idNovaVenda = controller.Inserir(venda);
            txtId.Text = idNovaVenda.ToString();

            bool estoqueAtualizadoComSucesso = true;

            // Insere os Itens de Venda e Reduz o Estoque
            foreach (var item in carrinho)
            {
                item.IdVenda = idNovaVenda;
                item.Subtotal = item.Quantidade * item.PrecoUnitario;
                itemVendaController.Inserir(item);

                // REDUÇÃO DO ESTOQUE
                if (long.TryParse(item.IdProduto, out long idProdutoEstoque))
                {
                    try
                    {
                        produtoController.ReduzirEstoque(idProdutoEstoque, item.Quantidade);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Alerta: Falha ao reduzir estoque do produto {item.IdProduto}. Erro: {ex.Message}", "Erro de Estoque");
                        estoqueAtualizadoComSucesso = false;
                    }
                }
                else
                {
                    MessageBox.Show($"Alerta: ID do produto {item.IdProduto} está em formato incorreto. Estoque não atualizado.", "Erro de Formato");
                    estoqueAtualizadoComSucesso = false;
                }
            }

            // Finalização e Feedback
            if (estoqueAtualizadoComSucesso)
            {
                MessageBox.Show("Venda registrada e estoque atualizado com sucesso!", "Transação Finalizada");
            }
            else
            {
                MessageBox.Show("Venda registrada, mas houve falhas na atualização de estoque. Verifique!", "Alerta de Estoque");
            }

            LimparCampos();
            AtualizarGrid();
        }

        // Botão EXCLUIR (Cancela a transação)
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text)) { MessageBox.Show("Selecione uma venda para excluir!"); return; }
            if (!int.TryParse(txtId.Text, out int idVenda)) { MessageBox.Show("ID da Venda inválido para exclusão.", "Erro"); return; }

            DialogResult confirmacao = MessageBox.Show($"Tem certeza que deseja excluir/cancelar a Venda {idVenda}?", "Confirmar Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (confirmacao == DialogResult.Yes)
            {
                // Exclui itens primeiro  e depois o cabeçalho
                itemVendaController.ExcluirItensPorVenda(idVenda);
                controller.Excluir(idVenda);

                MessageBox.Show("Venda excluída/cancelada com sucesso!");

                AtualizarGrid();
                LimparCampos();
            }
        }
        // Evento de Carregamento de Venda (Carrega venda existente ao clicar na grid)
        private void dgvVendas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verifica se o clique foi em uma linha válida
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvVendas.Rows[e.RowIndex];

                // Tenta obter o ID da Venda
                if (!int.TryParse(row.Cells["IdVenda"].Value.ToString(), out int idVenda)) return;

                // Preenche o campo ID (Crucial para o botão Excluir)
                txtId.Text = idVenda.ToString();

                // Preenche os campos de cabeçalho
                cmbCliente.SelectedValue = Convert.ToInt32(row.Cells["IdCliente"].Value);
                cmbUsuario.SelectedValue = Convert.ToInt32(row.Cells["IdUsuario"].Value);
                dtpDataVenda.Value = Convert.ToDateTime(row.Cells["DataVenda"].Value);
                txtValorTotal.Text = Convert.ToDecimal(row.Cells["ValorTotal"].Value).ToString("N2");

                //Carrega os itens daquela venda no carrinho para visualização
                carrinho = itemVendaController.GetItensByVenda(idVenda);
                AtualizarGridItens();
            }
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            string idProdutoString = txtProdutoId.Text.Trim();

            // Validações de item, quantidade e estoque
            if (string.IsNullOrWhiteSpace(idProdutoString) || txtNomeProduto.Text.Contains("Não Encontrado"))
            {
                MessageBox.Show("Busque e selecione um produto válido!", "Erro de Item");
                txtProdutoId.Focus();
                return;
            }
            if (!int.TryParse(txtQuantidade.Text, out int quantidade) || quantidade <= 0)
            {
                MessageBox.Show("Insira uma quantidade válida!");
                txtQuantidade.Focus();
                return;
            }

            // Garante que o ID é um long para buscar o produto no Controller
            if (!long.TryParse(idProdutoString, out long idProdutoLong))
            {
                MessageBox.Show("O Código de Barras não está no formato correto.", "Erro de Formato");
                return;
            }

            Produto produto = produtoController.GetById(idProdutoLong);

            // Verifica Estoque (Importante para evitar venda de estoque negativo)
            if (produto.Estoque < quantidade)
            {
                MessageBox.Show($"Estoque insuficiente! Disponível: {produto.Estoque}", "Erro de Estoque");
                return;
            }

            // Cria o Item de Venda e adiciona ao carrinho em memória
            ItemVenda novoItem = new ItemVenda
            {
                IdProduto = produto.IdProduto.ToString(),
                Quantidade = quantidade,
                PrecoUnitario = produto.Preco,
                NomeProduto = produto.Nome
            };

            carrinho.Add(novoItem);

            // Atualiza a exibição e prepara para o próximo item
            AtualizarGridItens();

            // Limpa campos de item
            txtProdutoId.Clear();
            txtQuantidade.Clear();
            txtNomeProduto.Clear();
            txtFornecedorProduto.Clear();
            txtProdutoId.Focus();
        }
    }
}