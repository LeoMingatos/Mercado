﻿using MERCADOPOO.Controller;
using MERCADOPOO.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq; 
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions; 

namespace MERCADOPOO
{
    // Formulário de Cadastro e Edição de Fornecedores.
    public partial class CadFornecedor : Form
    {
        // Instância do Controller para acesso à lógica de negócio e banco de dados.
        FornecedorController controller = new FornecedorController();

        public CadFornecedor()
        {
            InitializeComponent();
            AtualizarGrid(); // Carrega a lista de fornecedores ao iniciar.
        }

        // --- FUNÇÕES DE ROTINA ---

        // Limpa e recarrega todos os fornecedores no DataGridView.
        private void AtualizarGrid()
        {
            dgvFornecedores.DataSource = null;
            dgvFornecedores.DataSource = controller.GetAll();
        }

        // Define todos os campos de texto como vazios e coloca o foco na Razão Social.
        private void LimparCampos()
        {
            txtId.Clear();
            txtRazaoSocial.Clear();
            txtCnpj.Clear();
            txtTelefone.Clear();
            txtEmail.Clear();
            txtRazaoSocial.Focus();
        }

        // --- FUNÇÕES DE VALIDAÇÃO ---

        // Checa se o CNPJ tem 14 dígitos e se é apenas numérico.
        private bool IsCnpjValido(string cnpj)
        {
            // Remove caracteres não-numéricos
            string cnpjLimpo = new string(cnpj.Where(char.IsDigit).ToArray());

            if (cnpjLimpo.Length != 14)
            {
                return false;
            }
            return true;
        }

        // Validação de E-mail 
        private bool IsEmailValido(string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return true; 

            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            try
            {
                return Regex.IsMatch(email, pattern);
            }
            catch
            {
                return false;
            }
        }

        // Validação de Telefone (checa se o número de dígitos está entre 8 e 11).
        private bool IsTelefoneValido(string telefone)
        {
            if (string.IsNullOrWhiteSpace(telefone)) return true; 
            // Remove caracteres não-numéricos
            string telefoneLimpo = new string(telefone.Where(char.IsDigit).ToArray());

            return telefoneLimpo.Length >= 8 && telefoneLimpo.Length <= 11;
        }

        // --- EVENTOS DA INTERFACE ---

        // Botão NOVO (Prepara o formulário para um novo cadastro).
        private void btnNovo_Click_1(object sender, EventArgs e)
        {
            LimparCampos();
        }

        // Botão SALVAR (Faz a lógica unificada de INSERIR ou ALTERAR).
        private void btnSalvar_Click_1(object sender, EventArgs e)
        {
            // Validações Essenciais
            if (txtRazaoSocial.Text == "")
            {
                MessageBox.Show("Preencha a Razão Social!");
                txtRazaoSocial.Focus();
                return;
            }
            if (!IsCnpjValido(txtCnpj.Text)) { MessageBox.Show("O CNPJ inserido é inválido."); txtCnpj.Focus(); return; }
            if (!IsEmailValido(txtEmail.Text)) { MessageBox.Show("O E-mail inserido é inválido."); txtEmail.Focus(); return; }
            if (!IsTelefoneValido(txtTelefone.Text)) { MessageBox.Show("O Telefone inserido é inválido."); txtTelefone.Focus(); return; }

            // Cria o objeto Fornecedor
            Fornecedor fornecedor = new Fornecedor
            {
                RazaoSocial = txtRazaoSocial.Text,
                CNPJ = txtCnpj.Text,
                Telefone = txtTelefone.Text,
                Email = txtEmail.Text
            };

            // Lógica de Decisão: INSERIR ou ALTERAR
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                // INSERIR NOVO
                controller.Inserir(fornecedor);
                MessageBox.Show("Fornecedor cadastrado com sucesso!");
            }
            else
            {
                // ALTERAR EXISTENTE
                try
                {
                    fornecedor.IdFornecedor = Convert.ToInt32(txtId.Text);
                    controller.Alterar(fornecedor);
                    MessageBox.Show("Fornecedor atualizado com sucesso!");
                }
                catch (FormatException)
                {
                    MessageBox.Show("Erro: O ID do fornecedor deve ser um número inteiro válido.");
                    txtId.Focus();
                    return;
                }
            }

            AtualizarGrid();
            LimparCampos();
        }

        // Botão PESQUISAR (Abre a tela para seleção)
        private void btnPesquisar_Click_1(object sender, EventArgs e)
        {
            // Instancia e abre o formulário de pesquisa de fornecedores
            using (SeleFornecedor frmPesquisa = new SeleFornecedor())
            {
                // Abre o formulário
                if (frmPesquisa.ShowDialog() == DialogResult.OK)
                {
                    Fornecedor fornecedorSelecionado = frmPesquisa.FornecedorSelecionado;

                    if (fornecedorSelecionado != null)
                    {
                        // Se um fornecedor foi selecionado, preenche os campos com os dados retornados
                        LimparCampos();
                        txtId.Text = fornecedorSelecionado.IdFornecedor.ToString();
                        txtRazaoSocial.Text = fornecedorSelecionado.RazaoSocial;
                        txtCnpj.Text = fornecedorSelecionado.CNPJ;
                        txtTelefone.Text = fornecedorSelecionado.Telefone;
                        txtEmail.Text = fornecedorSelecionado.Email;

                        // Atualiza a grade para mostrar apenas esse fornecedor 
                        dgvFornecedores.DataSource = new List<Fornecedor> { fornecedorSelecionado };
                    }
                    else
                    {
                        // Se o usuário fechou ou cancelou, recarrega a grid completa
                        AtualizarGrid();
                    }
                }
            }
        }

        // Botão EXCLUIR
        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                MessageBox.Show("Selecione um fornecedor para excluir!");
                return;
            }

            if (!int.TryParse(txtId.Text, out int id))
            {
                MessageBox.Show("Erro: O ID do fornecedor para exclusão deve ser um número inteiro válido.");
                txtId.Focus();
                return;
            }

            controller.Excluir(id); // Chama o controller para deletar
            MessageBox.Show("Fornecedor excluído com sucesso!");

            AtualizarGrid();
            LimparCampos();
        }

        // Clique em uma célula da tabela (carrega dados para edição)
        private void dgvFornecedores_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvFornecedores.Rows[e.RowIndex];

                // Pega os dados da linha e preenche os campos
                txtId.Text = row.Cells["IdFornecedor"].Value.ToString();
                txtRazaoSocial.Text = row.Cells["RazaoSocial"].Value.ToString();
                txtCnpj.Text = row.Cells["CNPJ"].Value.ToString();
                txtTelefone.Text = row.Cells["Telefone"].Value.ToString();
                txtEmail.Text = row.Cells["Email"].Value.ToString();
            }
        }
    }
}