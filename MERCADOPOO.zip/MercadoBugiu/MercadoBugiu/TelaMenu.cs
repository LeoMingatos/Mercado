﻿using MercadoBugiu;
using MERCADOPOO.Util; // Classe estática para gerenciar o usuário logado
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MERCADOPOO
{
    // Formulário do Menu Principal (MDI Parent, geralmente)
    public partial class TelaMenu : Form
    {
        public TelaMenu()
        {
            InitializeComponent();
            // Aqui você pode adicionar a lógica para exibir o nome do usuário logado na barra de status
        }

        // --- NAVEGAÇÃO: CADASTRO ---

        // Leva para a tela de Cadastro de Cliente.
        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadCliente cadCliente = new CadCliente();
            cadCliente.Show();
        }

        // Leva para a tela de Cadastro de Produto.
        private void produtoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadProduto cadProduto = new CadProduto();
            cadProduto.Show();
        }

        // Leva para a tela de Cadastro de Fornecedor.
        private void fornecedirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadFornecedor cadFornecedor = new CadFornecedor();
            cadFornecedor.Show();
        }

        // Leva para a tela de Cadastro de Usuário.
        private void usuárioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadUsuario cadUsuario = new CadUsuario();
            cadUsuario.Show();
        }

        // --- NAVEGAÇÃO: MOVIMENTAÇÕES ---

        // Leva para a tela de Registro de Vendas (PDV).
        private void vendaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaVenda cadVenda = new TelaVenda();
            cadVenda.Show();
        }

        // Leva para a tela de Registro de Entrada de Estoque.
        private void entradaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaEntrada telaEntrada = new TelaEntrada();
            telaEntrada.Show();
        }

        // --- NAVEGAÇÃO: RELATÓRIOS E CONSULTAS ---

        // Leva para a tela de Consulta de Estoque Atual.
        private void estoqueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaEstoque telaEstoque = new TelaEstoque();
            telaEstoque.Show();
        }

        // Leva para a tela de Histórico de Vendas (Relatório de Vendas).
        private void históricoDeVendasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HistoricoVendas historicoVendas = new HistoricoVendas();
            historicoVendas.Show();
        }

        // --- NAVEGAÇÃO: SAIR---

        // Pergunta se deseja sair, desloga a sessão atual e retorna à tela de Login.
        private void sAIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Pergunta de confirmação
            if (MessageBox.Show("Deseja realmente sair da sua conta?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                return; // Se o usuário clicar em Não, cancela a saída
            }

            // Limpa os dados do usuário logado (Logout)
            SessaoAtual.EncerrarSessao();

            // Abre a tela de Login
            TelaLogin telaLogin = new TelaLogin();
            telaLogin.Show();

            // Fecha a tela do menu principal
            this.Close();
        }
    }
}