﻿using MERCADOPOO;
using MERCADOPOO.Controller;
using MERCADOPOO.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MercadoBugiu
{

    // Formulário de Registro de Entrada (Recebimento) de Estoque
    public partial class TelaEntrada : Form
    {
        // Controllers e Variáveis de Estado
        private readonly ProdutoController produtoController = new ProdutoController();
        private readonly FornecedorController fornecedorController = new FornecedorController();
        private Produto produtoAtual = null; // Armazena o objeto Produto sendo manipulado
        public TelaEntrada()
        {
            InitializeComponent();
            LimparCampos(); // Inicia a tela limpa
        }

        // --- FUNÇÕES DE ROTINA ---

        // Limpa todos os campos de entrada e reseta o objeto Produto em memória.
        private void LimparCampos()
        {
            txtProdutoId.Clear();
            txtProduto.Clear();
            txtFornecedor.Clear();
            txtEstoqueAtual.Clear();
            txtQuantidadeEntrada.Clear();

            produtoAtual = null; // Zera o objeto para evitar alterações incorretas
            txtProdutoId.Focus();
        }

        // Função auxiliar para preencher todos os detalhes do produto na tela.
        private void CarregarDetalhesProduto(Produto produto)
        {
            produtoAtual = produto; // Armazena o objeto completo

            // Preenche os campos do produto
            txtProdutoId.Text = produto.IdProduto.ToString();
            txtProduto.Text = produto.Nome;
            txtEstoqueAtual.Text = produto.Estoque.ToString(); // Exibe o estoque antes da entrada

            // Busca e preenche o Fornecedor (Razão Social)
            Fornecedor fornecedor = fornecedorController.GetById(produto.IdFornecedor);
            txtFornecedor.Text = fornecedor?.RazaoSocial ?? "[Fornecedor não cadastrado]";

            txtQuantidadeEntrada.Focus();
        }

        // --- EVENTOS DE INTERAÇÃO ---

        // Disparado ao sair do campo ID do produto (para busca via digitação).
        private void txtProdutoId_Leave(object sender, EventArgs e)
        {
            string idProdutoString = txtProdutoId.Text.Trim();

            // Limpa campos antes de buscar um novo item
            txtProduto.Clear();
            txtFornecedor.Clear();
            txtEstoqueAtual.Clear();
            txtQuantidadeEntrada.Clear();
            produtoAtual = null;

            if (string.IsNullOrWhiteSpace(idProdutoString)) return;

            try
            {
                // Valida o ID e busca o produto
                if (!long.TryParse(idProdutoString, out long idProdutoLong))
                {
                    MessageBox.Show("O Código de Barras é inválido.", "Erro de Formato");
                    txtProdutoId.Focus();
                    return;
                }

                Produto produto = produtoController.GetById(idProdutoLong);

                if (produto != null)
                {
                    CarregarDetalhesProduto(produto); // Preenche a tela com os dados
                }
                else
                {
                    MessageBox.Show("Produto não encontrado no cadastro.", "Busca Falhou");
                    txtProdutoId.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar produto: " + ex.Message, "Erro de Sistema");
            }
        }

        // Botão REGISTRAR ENTRADA
        private void btnEntrada_Click(object sender, EventArgs e)
        {
            if (produtoAtual == null)
            {
                MessageBox.Show("Primeiro, busque e selecione um produto válido.", "Atenção");
                txtProdutoId.Focus();
                return;
            }

            // Validação da quantidade de entrada
            if (!int.TryParse(txtQuantidadeEntrada.Text, out int quantidadeEntrada) || quantidadeEntrada <= 0)
            {
                MessageBox.Show("Digite uma quantidade de entrada válida e positiva.", "Atenção");
                txtQuantidadeEntrada.Focus();
                return;
            }

            try
            {
                // Calcula o novo estoque em memória
                int novoEstoque = produtoAtual.Estoque + quantidadeEntrada;

                // Atualiza o objeto e envia a alteração para o banco de dados
                produtoAtual.Estoque = novoEstoque;
                produtoController.Alterar(produtoAtual); // O método Alterar salva o novo estoque

                // Sucesso e Feedback
                MessageBox.Show($"Entrada de {quantidadeEntrada} unidades registrada com sucesso!\nNovo estoque total: {novoEstoque}", "Estoque Atualizado");

                LimparCampos(); // Limpa a tela para a próxima entrada
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao registrar entrada de estoque: {ex.Message}", "Erro de Banco de Dados");
            }
        }

        //Botão Pesquisar Produto
        private void btnPesquisa_Click(object sender, EventArgs e)
        {
            // Abre a tela de pesquisa de produtos
            using (PesquisaProduto frmPesquisa = new PesquisaProduto())
            {
                if (frmPesquisa.ShowDialog() == DialogResult.OK)
                {
                    Produto produtoSelecionado = frmPesquisa.ProdutoSelecionado;

                    if (produtoSelecionado != null)
                    {
                        // Usa o objeto retornado para preencher a tela
                        CarregarDetalhesProduto(produtoSelecionado);
                    }
                }
            }
        }
    }
}
