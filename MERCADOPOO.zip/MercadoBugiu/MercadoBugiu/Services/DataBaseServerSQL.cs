﻿using System.Data.SqlClient;
using System.Data;
using System;

namespace MERCADOPOO.Services
{
    // Classe para gerenciar a conexão com o BD
    public class DataBaseServerSQL
    {
        // String de conexão centralizada
        //. é a maquina local
        private readonly string connectionString =
           "Data Source=.\\MSSQLSERVER1;" +
           "Initial Catalog=MercadoBD;" +
           "Integrated Security=True;";

        // Método privado que cria nova conexão com o banco
        private SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        // Método público que executa comandos
        // INSERT, UPDATE e DELETE
        public int ExecuteSQL(SqlCommand command)
        {
            using (SqlConnection connection = GetConnection())
            {
                command.Connection = connection;
                connection.Open();
                return command.ExecuteNonQuery();
            }
        }

        // Método público que executa comando SELECT
        // Retorna apenas a primeira coluna da primeira linha
        public object ExecuteScalar(SqlCommand command)
        {
            using (SqlConnection connection = GetConnection())
            {
                command.Connection = connection;
                connection.Open();
                return command.ExecuteScalar();
            }
        }

        // Método público que executa comando SQL (SELECT)
        // Retorna todas as linhas e colunas da consulta
        public DataTable GetDataTable(SqlCommand command)
        {
            using (SqlConnection connection = GetConnection())
            {
                command.Connection = connection;
                using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command))
                {
                    DataTable dataTable = new DataTable();
                    // O DataAdapter abre e fecha a conexão automaticamente
                    sqlDataAdapter.Fill(dataTable);
                    return dataTable;
                }
            }
        }
    }
}